# ReaperShield — Good Samaritan Emergency Support Prototype

A responsive web prototype for accident reporting, emergency information, a Good Samaritan demo token, and first-aid guidance. The interface uses a dark violet/orange theme.

> **Important — prototype only:** This repository is not an official government, police, ambulance, or hospital service. The demo token/QR, dispatch response, donor alerts, and AWS-labelled telemetry are not official integrations and do not create or certify legal immunity. The local `/api/dispatch` route is a simulation. In a real emergency in India, contact the appropriate emergency service directly (for example, 112 or 108); do not rely on this prototype.

## Project files

```text
reapershield/
├── index.html              # Website entry point
├── style.css               # Responsive visual styling
├── app.js                  # Browser-side application logic
├── server.py               # Local Python API and Gemini proxy
├── assets/
│   └── haunted-road.svg    # Local sample-scene illustration
├── .env.example            # Safe environment-variable template
├── .gitignore              # Keeps secrets and local files out of Git
├── requirements.txt        # Optional cloud/automation packages
├── LICENSE
└── README.md
```

## Run locally (Windows)

1. Install Python 3.8 or newer.
2. Extract/clone this repository and open the project folder in VS Code.
3. Optional Gemini setup: copy `.env.example` to `.env`, open `.env`, and replace the placeholder with your own Gemini API key. Keep `.env` private; it is ignored by Git.
4. Open the VS Code terminal in the project folder and run:

   ```powershell
   python server.py
   ```

5. Open `http://localhost:8000` in your browser.

The server uses Python's standard library. No `pip install` step is required for local development. Without `GEMINI_API_KEY`, the app uses its built-in local fallback for the AI triage endpoint.

### Run on a phone on the same Wi-Fi

Run the server on your computer, find the computer's local IPv4 address, then open `http://YOUR-COMPUTER-IP:8000` on the phone. Both devices must be on the same network. Keep in mind that browser location, maps, and other integrations may require HTTPS and/or user permission.

## Upload to GitHub

1. Create a new **public** or **private** repository on GitHub.
2. Extract the ZIP file downloaded with this project.
3. Open the extracted `reapershield-github-ready` folder.
4. Upload the **contents** of that folder (not an extra nested folder) to the repository root.
5. Commit the files.

Or use Git:

```bash
git init
git add .
git commit -m "Initial ReaperShield prototype"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

## GitHub Pages limitation

GitHub Pages can host the static interface (`index.html`, `style.css`, `app.js`, and `assets/`), but it **cannot run `server.py`**. Therefore, Gemini triage and the local API endpoints will not work on a Pages-only deployment unless you deploy the Python API separately and configure the frontend to call that backend. Never put a Gemini API key in browser JavaScript or commit it to GitHub.

## API key safety

The uploaded source had a Gemini key hard-coded in `server.py`. It has been removed from this GitHub-ready package. Treat that earlier key as exposed: revoke/rotate it in the provider console before using Gemini again. Put only a replacement key in your local `.env` file.

## Scope and implementation status

- **Implemented in the prototype:** website UI, client-side interactions, local first-aid protocol endpoint, demo QR/token display, and local sample-scene graphic.
- **Simulated:** `/api/dispatch` response and AWS-labelled dispatch/storage notifications.
- **Requires configuration:** Gemini API integration (a valid key in `.env`).
- **Not implemented by this repository:** production hospital/ambulance dispatch, verified legal-token issuance, official QR verification, actual SMS/push donor broadcast, or live AWS infrastructure.

This is a hackathon/demo starting point, not a deployable emergency-response service. Have legal, medical, privacy, and security claims reviewed before any real-world release.
