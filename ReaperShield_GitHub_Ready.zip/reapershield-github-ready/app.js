// ReaperShield - Core Application Logic
// Supreme Court Good Samaritan Legal Protection & Trauma Hospital Dispatch Engine

let currentCoords = { lat: 13.0827, lng: 80.2707 }; // Default: Chennai Central / Anna Salai
let hospitalCoords = { lat: 13.0815, lng: 80.2785 }; // Rajiv Gandhi Govt General Hospital
let selectedSeverity = 'critical';
let qrCodeInstance = null;

// Initialize on DOM Load
document.addEventListener('DOMContentLoaded', () => {
  initMap();
  getCurrentLocation();
  generateInitialQrCode("RS-2026-INIT");
  startHospitalCountdown();
});


// =========================================================================
// 1. TOUCH-SWIPE & PAN INTERACTIVE MAP ENGINE (Zero-Fail on Every Device)
// =========================================================================
let map = null;
let markerAccident = null;
let markerHospital = null;
let routeLine = null;
let activeMapMode = 'tactical'; // Start in guaranteed Tactical HUD mode
let streetLayer = null, satelliteLayer = null, labelsLayer = null;

let mapPanX = 0, mapPanY = 0;
let mapScale = 1.0;
let isPanning = false;
let panStartX = 0, panStartY = 0;

function initMap() {
  setMapMode('tactical');
  initTouchSwipePanMap();
}

function initTouchSwipePanMap() {
  const container = document.getElementById('map-tactical-view');
  const svgContent = document.getElementById('map-svg-content');
  if (!container || !svgContent) return;

  function applyTransform() {
    svgContent.style.transform = `translate(${mapPanX}px, ${mapPanY}px) scale(${mapScale})`;
    svgContent.style.transition = isPanning ? 'none' : 'transform 0.15s ease-out';
  }

  // Mobile Touch Pan (Swipe in all directions)
  container.addEventListener('touchstart', (e) => {
    if (e.touches.length === 1) {
      isPanning = true;
      panStartX = e.touches[0].clientX - mapPanX;
      panStartY = e.touches[0].clientY - mapPanY;
    }
  }, { passive: true });

  container.addEventListener('touchmove', (e) => {
    if (!isPanning || e.touches.length !== 1) return;
    mapPanX = e.touches[0].clientX - panStartX;
    mapPanY = e.touches[0].clientY - panStartY;
    // Boundary clamp
    mapPanX = Math.max(-250, Math.min(250, mapPanX));
    mapPanY = Math.max(-150, Math.min(150, mapPanY));
    applyTransform();
  }, { passive: true });

  container.addEventListener('touchend', () => {
    isPanning = false;
    applyTransform();
  }, { passive: true });

  // Desktop Mouse Drag to Swipe / Pan
  container.addEventListener('mousedown', (e) => {
    isPanning = true;
    panStartX = e.clientX - mapPanX;
    panStartY = e.clientY - mapPanY;
  });

  window.addEventListener('mousemove', (e) => {
    if (!isPanning) return;
    mapPanX = e.clientX - panStartX;
    mapPanY = e.clientY - panStartY;
    mapPanX = Math.max(-250, Math.min(250, mapPanX));
    mapPanY = Math.max(-150, Math.min(150, mapPanY));
    applyTransform();
  });

  window.addEventListener('mouseup', () => {
    if (isPanning) {
      isPanning = false;
      applyTransform();
    }
  });
}

function zoomMap(delta) {
  mapScale = Math.max(0.7, Math.min(2.5, mapScale + delta));
  const svgContent = document.getElementById('map-svg-content');
  if (svgContent) {
    svgContent.style.transform = `translate(${mapPanX}px, ${mapPanY}px) scale(${mapScale})`;
    svgContent.style.transition = 'transform 0.25s cubic-bezier(0.16, 1, 0.3, 1)';
  }
}

function recenterMap() {
  mapPanX = 0;
  mapPanY = 0;
  mapScale = 1.0;
  const svgContent = document.getElementById('map-svg-content');
  if (svgContent) {
    svgContent.style.transform = 'translate(0px, 0px) scale(1.0)';
    svgContent.style.transition = 'transform 0.4s cubic-bezier(0.16, 1, 0.3, 1)';
  }
  if (map && markerAccident && markerHospital) {
    map.fitBounds([
      [currentCoords.lat, currentCoords.lng],
      [hospitalCoords.lat, hospitalCoords.lng]
    ], { padding: [30, 30] });
    map.invalidateSize();
  }
}

function setMapMode(mode) {
  activeMapMode = mode;
  const tacticalView = document.getElementById('map-tactical-view');
  const leafletView = document.getElementById('map-leaflet-view');
  const btnTactical = document.getElementById('btn-map-tactical');
  const btnStreet = document.getElementById('btn-map-street');
  const btnSat = document.getElementById('btn-map-sat');

  const activeCls = "px-2.5 py-1 rounded bg-cyan-600 text-white font-bold text-[10px] shadow-[0_0_12px_rgba(6,182,212,0.6)] transition-all flex items-center gap-1 cursor-pointer";
  const inactiveCls = "px-2.5 py-1 rounded bg-purple-950/80 border border-purple-500/30 text-purple-300 text-[10px] hover:text-white transition-all flex items-center gap-1 cursor-pointer";

  if (mode === 'tactical') {
    if (leafletView) leafletView.classList.add('hidden');
    if (tacticalView) tacticalView.classList.remove('hidden');
    if (btnTactical) btnTactical.className = activeCls;
    if (btnStreet) btnStreet.className = inactiveCls;
    if (btnSat) btnSat.className = inactiveCls;
    return;
  }

  // Switch to Leaflet Live View
  if (tacticalView) tacticalView.classList.add('hidden');
  if (leafletView) leafletView.classList.remove('hidden');

  if (mode === 'street') {
    if (btnStreet) btnStreet.className = activeCls;
    if (btnTactical) btnTactical.className = inactiveCls;
    if (btnSat) btnSat.className = inactiveCls;
    ensureLeafletInitialized('street');
  } else if (mode === 'satellite') {
    if (btnSat) btnSat.className = activeCls;
    if (btnTactical) btnTactical.className = inactiveCls;
    if (btnStreet) btnStreet.className = inactiveCls;
    ensureLeafletInitialized('satellite');
  }
}

function ensureLeafletInitialized(layerType) {
  const container = document.getElementById('leaflet-map');
  if (!container || typeof L === 'undefined') {
    console.warn("Leaflet not available, keeping Tactical Radar HUD.");
    setMapMode('tactical');
    return;
  }

  if (!map) {
    try {
      map = L.map('leaflet-map', {
        zoomControl: true,
        attributionControl: false,
        dragging: true,
        touchZoom: true,
        scrollWheelZoom: true,
        tap: false
      }).setView([currentCoords.lat, currentCoords.lng], 14);

      streetLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 19
      });

      satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 19
      });

      labelsLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 19
      });

      const accidentIcon = L.divIcon({
        className: 'custom-accident-marker',
        html: '<div class="w-7 h-7 rounded-full bg-red-600 border-2 border-white shadow-lg flex items-center justify-center text-xs text-white font-bold animate-pulse">!</div>',
        iconSize: [28, 28],
        iconAnchor: [14, 14]
      });

      const hospitalIcon = L.divIcon({
        className: 'custom-hosp-marker',
        html: '<div class="w-8 h-8 rounded-xl bg-emerald-600 border-2 border-white shadow-lg flex items-center justify-center text-sm text-white font-bold"><i class="fa-solid fa-hospital"></i></div>',
        iconSize: [32, 32],
        iconAnchor: [16, 16]
      });

      markerAccident = L.marker([currentCoords.lat, currentCoords.lng], { icon: accidentIcon })
        .addTo(map)
        .bindPopup("<strong class='text-red-600'>🚨 ACCIDENT SCENE</strong><br><span class='text-xs'>Tambaram, Chennai</span>");

      markerHospital = L.marker([hospitalCoords.lat, hospitalCoords.lng], { icon: hospitalIcon })
        .addTo(map)
        .bindPopup("<strong class='text-emerald-700'>🏥 RGGGH Trauma Center</strong><br><span class='text-xs'>Level-1 Trauma Hub</span>");

      routeLine = L.polyline([
        [currentCoords.lat, currentCoords.lng],
        [hospitalCoords.lat, hospitalCoords.lng]
      ], {
        color: '#06b6d4',
        weight: 6,
        dashArray: '8, 10'
      }).addTo(map);

      map.fitBounds([
        [currentCoords.lat, currentCoords.lng],
        [hospitalCoords.lat, hospitalCoords.lng]
      ], { padding: [30, 30] });

    } catch(err) {
      console.warn("Leaflet init error:", err);
      setMapMode('tactical');
      return;
    }
  }

  if (layerType === 'satellite') {
    if (streetLayer) try { map.removeLayer(streetLayer); } catch(e) {}
    map.addLayer(satelliteLayer);
    map.addLayer(labelsLayer);
  } else {
    if (satelliteLayer) try { map.removeLayer(satelliteLayer); } catch(e) {}
    if (labelsLayer) try { map.removeLayer(labelsLayer); } catch(e) {}
    map.addLayer(streetLayer);
  }

  setTimeout(() => { if (map) map.invalidateSize(); }, 150);
  setTimeout(() => { if (map) map.invalidateSize(); }, 500);
}


// 2. Fetch Live Geolocation
function getCurrentLocation() {
  const locInput = document.getElementById('incident-location');
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        currentCoords.lat = position.coords.latitude;
        currentCoords.lng = position.coords.longitude;
        
        locInput.value = `${currentCoords.lat.toFixed(5)}° N, ${currentCoords.lng.toFixed(5)}° E (GPS Verified)`;
        const modalCoords = document.getElementById('emergency-modal-coords');
        if (modalCoords) modalCoords.innerText = locInput.value;
        
        if (map && markerAccident) {
          markerAccident.setLatLng([currentCoords.lat, currentCoords.lng]);
          routeLine.setLatLngs([
            [currentCoords.lat, currentCoords.lng],
            [hospitalCoords.lat, hospitalCoords.lng]
          ]);
          map.panTo([currentCoords.lat, currentCoords.lng]);
        }
      },
      (error) => {
        console.warn("GPS auto-detect denied/unavailable. Using default coordinates.");
        locInput.value = `13.0827° N, 80.2707° E (Anna Salai, Chennai)`;
      }
    );
  } else {
    locInput.value = `13.0827° N, 80.2707° E (Anna Salai, Chennai)`;
  }
}

// 3. Severity Selector Handler
function selectSeverity(level) {
  selectedSeverity = level;
  const btns = {
    critical: document.getElementById('sev-critical'),
    moderate: document.getElementById('sev-moderate'),
    minor: document.getElementById('sev-minor')
  };

  Object.keys(btns).forEach(key => {
    btns[key].className = 'p-2.5 rounded-xl border border-purple-500/30 bg-purple-950/40 text-purple-300 text-xs font-semibold text-center hover:bg-purple-900/40 transition-all';
  });

  if (level === 'critical') {
    btns.critical.className = 'p-2.5 rounded-xl border border-fuchsia-500 bg-fuchsia-950/60 text-fuchsia-200 text-xs font-semibold text-center glow-magenta';
  } else if (level === 'moderate') {
    btns.moderate.className = 'p-2.5 rounded-xl border border-purple-500 bg-purple-950/60 text-purple-200 text-xs font-semibold text-center glow-purple';
  } else {
    btns.minor.className = 'p-2.5 rounded-xl border border-emerald-500 bg-emerald-950/50 text-emerald-200 text-xs font-semibold text-center shadow';
  }
}

// 4. Photo Upload & Simulated AWS Rekognition Scanner
function handlePhotoUpload(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (e) => {
    document.getElementById('upload-placeholder').classList.add('hidden');
    const previewDiv = document.getElementById('upload-preview');
    previewDiv.classList.remove('hidden');
    document.getElementById('preview-img').src = e.target.result;
    
    // Update AI tags for uploaded photo
    document.getElementById('ai-scene-tag').innerText = "Live Uploaded Incident";
    document.getElementById('ai-hazard-tag').innerText = "Analyzing Obstacles (Rekognition)...";
    setTimeout(() => {
      document.getElementById('ai-hazard-tag').innerText = "Vehicle Impact Verified (Confidence 96.8%)";
    }, 800);
  };
  reader.readAsDataURL(file);
}

// 4b. Load Sample Themed Scene (Haunted Roadside Accident)
function loadSampleScene() {
  document.getElementById('upload-placeholder').classList.add('hidden');
  const previewDiv = document.getElementById('upload-preview');
  previewDiv.classList.remove('hidden');
  document.getElementById('preview-img').src = "assets/haunted-road.svg";
  
  document.getElementById('ai-scene-tag').innerText = "Dark Rural Roadside (Gothic/Halloween Corridor)";
  document.getElementById('ai-hazard-tag').innerText = "High Hazard: Unlit Cobblestone Obstacle";
  document.getElementById('ai-privacy-tag').innerText = "Zero Faces Detected (Safe for Dispatch)";
  
  // Audio confirmation
  speakAnnouncement("Sample midnight incident scene loaded with AWS Rekognition telemetry.");
}

function resetPhoto() {
  document.getElementById('photo-input').value = "";
  document.getElementById('upload-placeholder').classList.remove('hidden');
  document.getElementById('upload-preview').classList.add('hidden');
}

// 5. Anonymous Mode Toggle
function toggleAnonymous(checkbox) {
  const nameInput = document.getElementById('bystander-name');
  if (checkbox.checked) {
    nameInput.disabled = true;
    nameInput.value = "Anonymous Good Samaritan";
    nameInput.classList.add('text-slate-400');
  } else {
    nameInput.disabled = false;
    nameInput.value = "";
    nameInput.placeholder = "Enter your name (Optional)";
    nameInput.classList.remove('text-slate-400');
    nameInput.focus();
  }
}

// 6. Handle Emergency Dispatch & Token Generation (The Core Magic)
function handleDispatch(event) {
  event.preventDefault();
  
  const dispatchBtn = document.getElementById('dispatch-btn');
  dispatchBtn.disabled = true;
  dispatchBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-2"></i> CONNECTING AWS DISPATCH &amp; GENERATING SHIELD...`;

  setTimeout(() => {
    // Generate Random Token ID
    const randomHex = Math.floor(1000 + Math.random() * 9000).toString(16).toUpperCase();
    const tokenId = `RS-2026-X${randomHex}`;
    const timestamp = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ", Today";

    // Update Token UI
    document.getElementById('cert-token-id').innerText = tokenId;
    document.getElementById('cert-timestamp').innerText = timestamp;
    
    const badge = document.getElementById('token-badge-status');
    badge.className = "px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-emerald-950 border border-emerald-500/50 text-emerald-400 animate-pulse";
    badge.innerText = "IMMUNITY ACTIVE • ZERO LIABILITY";

    // Highlight Card
    const tokenCard = document.getElementById('token-card-section');
    tokenCard.classList.remove('border-slate-800');
    tokenCard.classList.add('border-emerald-500', 'glow-cyan');

    // Generate Scannable QR Code
    const verificationUrl = `https://reapershield.gov.in/verify?token=${tokenId}&act=MV_SEC_134A`;
    generateInitialQrCode(verificationUrl);

    // Play Voice Notification via Web Speech API
    speakAnnouncement(`Good Samaritan Legal Immunity Token Generated. Zero liability enforced. Emergency blood alert for ${selectedBloodGroup} transmitted to nearby donors.`);

    // Trigger Hyperlocal Blood Donor Broadcast
    broadcastDonorAlert();

    // 5b. Transmit Telemetry to AWS Backend (API Gateway -> Lambda -> DynamoDB -> S3 -> SNS)
    try {
      const dispatchPayload = {
        token_id: tokenId,
        location: inputLoc,
        lat: 12.9249,
        lng: 80.1481,
        severity: 'CRITICAL',
        blood_group: 'O-',
        victim_notes: '1-Tap Accident Beacon broadcasted via Citizen Portal'
      };
      fetch(`${API_BASE}/api/dispatch`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dispatchPayload)
      })
      .then(res => res.json())
      .then(data => {
        console.log('⚡ AWS Backend Response:', data);
        if (data.status === 'SUCCESS') {
          console.log(`✅ Stored to AWS DynamoDB: ${data.tokenId} | Legal Protection: ${data.legalStatus}`);
        }
      })
      .catch(err => {
        console.warn('Backend telemetry sync note (running with local resilience):', err);
      });
    } catch (e) {
      console.warn('Dispatch network error:', e);
    }

    // Update Hospital Incident Time
    document.getElementById('hosp-incident-time').innerText = timestamp;

    // Reset Button
    dispatchBtn.disabled = false;
    dispatchBtn.innerHTML = `<i class="fa-solid fa-circle-check text-emerald-400 text-lg mr-2"></i> <span>LEGAL SHIELD ACTIVATED (DISPATCHED)</span>`;

    // Smooth Scroll to Certificate
    tokenCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, 1200);
}

// 7. QR Code Generator
// 7. Bulletproof Vector SVG QR Code Generator (Zero-Fail on Mobile & Offline)
function generateInitialQrCode(text) {
  const qrContainer = document.getElementById('qrcode');
  const modalQrContainer = document.getElementById('modal-qrcode');
  
  try {
    const tempDiv = document.createElement('div');
    const qr = new QRCode(tempDiv, {
      text: text,
      width: 180,
      height: 180,
      colorDark: "#050508",
      colorLight: "#ffffff",
      correctLevel: QRCode.CorrectLevel.M
    });

    const model = qr._oQRCode;
    if (model && typeof model.getModuleCount === 'function') {
      const count = model.getModuleCount();
      const rects = [];
      for (let r = 0; r < count; r++) {
        for (let c = 0; c < count; c++) {
          if (model.isDark(r, c)) {
            rects.push(`<rect x="${c}" y="${r}" width="1" height="1" fill="#050508"/>`);
          }
        }
      }
      const svgMarkup = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${count} ${count}" shape-rendering="crispEdges" style="width:100%;height:100%;display:block;background:#ffffff;"><rect width="${count}" height="${count}" fill="#ffffff"/>${rects.join('')}</svg>`;
      
      if (qrContainer) qrContainer.innerHTML = svgMarkup;
      if (modalQrContainer) modalQrContainer.innerHTML = svgMarkup;
      return;
    }
  } catch (err) {
    console.warn('Dynamic SVG QR generation failed, falling back:', err);
  }
  
  // Standard fallback
  if (qrContainer && !qrContainer.innerHTML.trim()) {
    try {
      new QRCode(qrContainer, {
        text: text,
        width: 80,
        height: 80,
        colorDark: "#050508",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.M
      });
    } catch (e) {
      console.error('Standard fallback failed:', e);
    }
  }
}

// Tap-to-Enlarge QR Modal Controls
function openQrModal() {
  const modal = document.getElementById('qr-enlarge-modal');
  if (modal) modal.classList.remove('hidden');
}

function closeQrModal() {
  const modal = document.getElementById('qr-enlarge-modal');
  if (modal) modal.classList.add('hidden');
}

function copyQrVerificationUrl() {
  const token = document.getElementById('good-samaritan-token')?.innerText || 'RS-2026-IMMUNITY-8924';
  const url = `https://reapershield.gov.in/verify?token=${token}&act=MV_SEC_134A`;
  if (navigator.clipboard) {
    navigator.clipboard.writeText(url).then(() => {
      alert('✅ Verification link copied to clipboard: ' + url);
    });
  } else {
    prompt('Verification Link:', url);
  }
}

// 8. Text-to-Speech Accessibility
function speakAnnouncement(text) {
  if ('speechSynthesis' in window) {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    window.speechSynthesis.speak(utterance);
  }
}

// 9. View Switcher (Bystander vs Hospital Dashboard)
function switchView(viewName) {
  const bystanderTab = document.getElementById('tab-bystander');
  const hospitalTab = document.getElementById('tab-hospital');
  const hospSection = document.getElementById('hospital-dashboard');
  const heroSection = document.getElementById('hero');

  if (viewName === 'hospital') {
    if (hospitalTab) hospitalTab.className = "px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 bg-red-600 text-white shadow-md";
    if (bystanderTab) bystanderTab.className = "px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 text-purple-300 hover:text-white";
    if (hospSection) {
      hospSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
      hospSection.classList.add('ring-2', 'ring-red-500');
      setTimeout(() => hospSection.classList.remove('ring-2', 'ring-red-500'), 2500);
    }
    setTimeout(() => { if (map) map.invalidateSize(); }, 300);
  } else {
    if (bystanderTab) bystanderTab.className = "px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 bg-purple-600 text-white shadow-md";
    if (hospitalTab) hospitalTab.className = "px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 text-purple-300 hover:text-white";
    if (heroSection) heroSection.scrollIntoView({ behavior: 'smooth' });
    setTimeout(() => { if (map) map.invalidateSize(); }, 300);
  }
}

// 10. Countdown Timer for Hospital Arrival (8 mins matching reference image)
function startHospitalCountdown() {
  let seconds = 480; // 8 mins
  const display = document.getElementById('hosp-countdown');
  setInterval(() => {
    if (seconds > 0) {
      seconds--;
      const mins = Math.floor(seconds / 60);
      const remSecs = seconds % 60;
      if (display) display.innerText = `${mins < 10 ? '0' : ''}${mins}:${remSecs < 10 ? '0' : ''}${remSecs}`;
    }
  }, 1000);
}

// 11. Reference Theme 1-Tap Accident Reporting & Token Generation
function trigger1TapReportSubmit() {
  const btn = document.getElementById('btn-1tap-report');
  const txtBtn = document.getElementById('txt-1tap-btn');
  if (btn) {
    btn.disabled = true;
    if (txtBtn) txtBtn.innerText = "Transmitting Rescue Beacon...";
  }

  // Generate official Token ID matching reference image format: GST-2026-1103-XXXX
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  const tokenId = `GST-2026-1103-${randomSuffix}`;
  const now = new Date();
  const timeStr = now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + " • " + now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });

  setTimeout(() => {
    // 1. Update Token ID and Timestamp in Parchment Scroll (Panel 3)
    const tokenElem = document.getElementById('cert-token-id');
    if (tokenElem) tokenElem.innerText = tokenId;
    const timeElem = document.getElementById('cert-timestamp');
    if (timeElem) timeElem.innerText = timeStr;
    const badgeStatus = document.getElementById('token-badge-status');
    if (badgeStatus) {
      badgeStatus.className = "px-2.5 py-0.5 rounded-full text-[9px] font-mono font-bold bg-emerald-800 text-emerald-100 shadow animate-pulse";
      badgeStatus.innerText = "✓ STATUTORY IMMUNITY ACTIVE";
    }

    // 2. Generate verifiable QR Code
    const verificationUrl = `https://reapershield.gov.in/verify?token=${tokenId}&act=MV_SEC_134A&status=PROTECTED_GOOD_SAMARITAN`;
    generateInitialQrCode(verificationUrl);

    // 3. Update Hospital Dashboard Incoming Casualty Card (Panel 4)
    const hospLoc = document.getElementById('hosp-incident-location');
    const inputLoc = document.getElementById('incident-location-field')?.value || "Tambaram, Chennai";
    if (hospLoc) hospLoc.innerText = inputLoc;

    const hospCountdown = document.getElementById('hosp-countdown');
    if (hospCountdown) hospCountdown.innerText = "08:00";

    const bloodStatus = document.getElementById('hosp-blood-status');
    if (bloodStatus) bloodStatus.innerText = "Blood Bank Alerted (O-ve En Route)";

    // 4. Voice Audio Announcement
    speakAnnouncement(`Good Samaritan Legal Immunity Token Generated. Token ID ${tokenId}. Statutory zero liability active under Section 134A. Paramedics and Rajiv Gandhi General Hospital trauma team dispatched.`);

    // 5. Broadcast to BloodLine Donors
    broadcastDonorAlert();

    // 6. Invalidate Map size so route renders crisp
    setTimeout(() => { if (map) map.invalidateSize(); }, 300);

    // 7. Reset button
    if (btn) {
      btn.disabled = false;
      if (txtBtn) txtBtn.innerText = "1-Tap Report (Issued: " + tokenId + ")";
    }

    // 8. Smoothly scroll down to the generated Good Samaritan Token
    const tokenSection = document.getElementById('legal-token-section');
    if (tokenSection) {
      tokenSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
      tokenSection.classList.add('ring-2', 'ring-amber-400');
      setTimeout(() => tokenSection.classList.remove('ring-2', 'ring-amber-400'), 3000);
    }
  }, 900);
}

function handleLocationOnlyReport() {
  trigger1TapReportSubmit();
}

function scrollToAiTriage() {
  const el = document.getElementById('ai-triage-hub');
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// 11. WhatsApp Share Helper
function shareToWhatsApp() {
  const tokenId = document.getElementById('cert-token-id').innerText;
  const msg = encodeURIComponent(
    `🚨 *REAPERSHIELD: GOOD SAMARITAN LEGAL IMMUNITY PASS*

` +
    `Token ID: *${tokenId}*
` +
    `Status: *Protected Rescuer (Zero Liability)*
` +
    `Legal Authority: Supreme Court WP(C) 235/2012 & Sec 134A Motor Vehicles Act.

` +
    `Hospital staff and police shall NOT detain or question this rescuer without consent.`
  );
  window.open(`https://api.whatsapp.com/send?text=${msg}`, '_blank');
}

// 12. AWS Architecture Modal Toggle
function toggleAwsModal() {
  const modal = document.getElementById('aws-modal');
  modal.classList.toggle('hidden');
}


// ==========================================
// 13. HALLOWEEN HORROR LIGHTNING GENERATOR
// ==========================================
function triggerLightning() {
  const overlay = document.getElementById('lightning-overlay');
  if (!overlay) return;

  // Realistic Double-Flash Lightning
  overlay.classList.add('flash-active');
  setTimeout(() => {
    overlay.classList.remove('flash-active');
    setTimeout(() => {
      overlay.classList.add('flash-active');
      setTimeout(() => {
        overlay.classList.remove('flash-active');
      }, 100);
    }, 70);
  }, 90);
}

// Periodic Atmospheric Lightning (Every 25 seconds)
function scheduleAutoLightning() {
  setInterval(() => {
    if (Math.random() > 0.3) {
      triggerLightning();
    }
  }, 24000);
}

// ==========================================
// 14. WEB AUDIO AMBIENT DRONE & HEARTBEAT
// ==========================================
let audioCtx = null;
let isAudioPlaying = false;
let ambientOsc = null;
let heartbeatInterval = null;

function toggleSpookyAudio() {
  const btn = document.getElementById('audio-toggle-btn');
  const icon = document.getElementById('audio-icon');
  const label = document.getElementById('audio-label');

  if (!audioCtx) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }

  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }

  if (!isAudioPlaying) {
    // Start Eerie Low-Frequency Horror Drone (45 Hz Triangle wave)
    ambientOsc = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();
    const filter = audioCtx.createBiquadFilter();

    ambientOsc.type = 'triangle';
    ambientOsc.frequency.setValueAtTime(46, audioCtx.currentTime); // Deep eerie drone

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(120, audioCtx.currentTime);

    gainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);

    ambientOsc.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(audioCtx.destination);
    ambientOsc.start();

    // Start Rhythmic Heartbeat ("Thump-thump")
    startHeartbeatLoop();

    isAudioPlaying = true;
    icon.className = "fa-solid fa-volume-high text-emerald-400";
    label.innerText = currentLang === 'ta' ? "ஆடியோ: ON" : "Audio: ON";
    btn.classList.add('border-emerald-500', 'glow-cyan');
  } else {
    // Stop Audio
    if (ambientOsc) {
      ambientOsc.stop();
      ambientOsc.disconnect();
    }
    if (heartbeatInterval) {
      clearInterval(heartbeatInterval);
    }
    isAudioPlaying = false;
    icon.className = "fa-solid fa-volume-xmark text-slate-400";
    label.innerText = currentLang === 'ta' ? "ஆடியோ: OFF" : "Audio: OFF";
    btn.classList.remove('border-emerald-500', 'glow-cyan');
  }
}

function playSingleThump(freq, duration, gainLevel) {
  if (!audioCtx || !isAudioPlaying) return;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();

  osc.type = 'sine';
  osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(30, audioCtx.currentTime + duration);

  gain.gain.setValueAtTime(gainLevel, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);

  osc.connect(gain);
  gain.connect(audioCtx.destination);
  osc.start();
  osc.stop(audioCtx.currentTime + duration);
}

function startHeartbeatLoop() {
  heartbeatInterval = setInterval(() => {
    // Dual pulse: Thump-thump
    playSingleThump(68, 0.14, 0.15);
    setTimeout(() => {
      playSingleThump(52, 0.18, 0.12);
    }, 180);
  }, 950); // ~75-80 BPM
}

// ==========================================
// 15. LIVE EKG WAVEFORM CANVAS ANIMATOR
// ==========================================
let ekgPoints = [];
let ekgIndex = 0;

function initEkg() {
  const canvas = document.getElementById('ekg-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  
  // Set real canvas dimensions
  canvas.width = canvas.offsetWidth || 260;
  canvas.height = 24;

  const width = canvas.width;
  const height = canvas.height;
  const mid = height / 2;

  // Pre-generate standard ECG waveform pattern
  const pattern = [0, 0, 0, 0, 1, -1, 0, 0, 2, -12, 10, -3, 1, 0, 0, 0, 0, 0, 0, 0];
  let x = 0;
  let history = [];

  function draw() {
    ctx.fillStyle = 'rgba(10, 5, 20, 0.22)';
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = '#c084fc';
    ctx.lineWidth = 1.8;
    ctx.shadowColor = '#e879f9';
    ctx.shadowBlur = 8;

    ctx.beginPath();
    ctx.moveTo(x - 2, history[history.length - 2] || mid);

    const val = pattern[ekgIndex % pattern.length];
    const y = mid + val;
    ctx.lineTo(x, y);
    ctx.stroke();

    history.push(y);
    if (history.length > width) history.shift();

    x += 2;
    if (x > width) {
      x = 0;
      ctx.clearRect(0, 0, width, height);
    }
    ekgIndex++;

    requestAnimationFrame(draw);
  }

  draw();
}

// ==========================================
// 15B. INTERACTIVE PUMPKIN EFFECT & SPARKLES
// ==========================================
function triggerPumpkinSparkles(event) {
  const x = event.clientX || window.innerWidth / 2;
  const y = event.clientY || window.innerHeight / 3;

  const colors = ['#c084fc', '#e879f9', '#f59e0b', '#fbbf24', '#ffffff', '#a855f7'];

  // Spawn 24 floating spark particles
  for (let i = 0; i < 24; i++) {
    const spark = document.createElement('div');
    spark.className = 'sparkle-particle';
    const size = Math.floor(Math.random() * 8) + 4;
    const color = colors[Math.floor(Math.random() * colors.length)];
    const angle = (Math.PI * 2 * i) / 24 + (Math.random() - 0.5) * 0.5;
    const distance = Math.floor(Math.random() * 110) + 40;
    const dx = Math.cos(angle) * distance;
    const dy = Math.sin(angle) * distance;

    spark.style.width = `${size}px`;
    spark.style.height = `${size}px`;
    spark.style.backgroundColor = color;
    spark.style.boxShadow = `0 0 12px ${color}`;
    spark.style.left = `${x}px`;
    spark.style.top = `${y}px`;
    spark.style.setProperty('--dx', `${dx}px`);
    spark.style.setProperty('--dy', `${dy}px`);

    document.body.appendChild(spark);
    setTimeout(() => spark.remove(), 1200);
  }

  // Play Spooky Pumpkin Chime Sound via Web Audio API
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (AudioCtx) {
      const actx = new AudioCtx();
      const freqs = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6 chord
      freqs.forEach((freq, idx) => {
        const osc = actx.createOscillator();
        const gain = actx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, actx.currentTime);
        
        gain.gain.setValueAtTime(0.08, actx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, actx.currentTime + 1.2 + idx * 0.15);

        osc.connect(gain);
        gain.connect(actx.destination);
        osc.start(actx.currentTime + idx * 0.04);
        osc.stop(actx.currentTime + 1.5);
      });
    }
  } catch (err) {
    console.log("AudioContext blocked or uninitialized:", err);
  }

  // Speak announcement in Tamil or English
  speakAnnouncement(currentLang === 'ta' 
    ? "ரீப்பர் ஷீல்ட் சட்டப் பாதுகாப்பு தயார்! உதவும் நபருக்கு உச்ச நீதிமன்ற உத்தரவுப்படி முழு சட்டப் பாதுகாப்பு உண்டு!" 
    : "Jack-o'-lantern Good Samaritan Protection Active! 100% Zero-Liability under Section 134A!");
}

// Live Golden Hour Countdown decrement
let goldenSeconds = 8 * 60;
function initGoldenHourTimer() {
  setInterval(() => {
    if (goldenSeconds > 0) goldenSeconds--;
    const mins = Math.floor(goldenSeconds / 60).toString().padStart(2, '0');
    const secs = (goldenSeconds % 60).toString().padStart(2, '0');
    const display = document.getElementById('hero-countdown-min');
    if (display) display.innerText = `${mins}:${secs}`;
  }, 1000);
}

// ==========================================
// 16. BILINGUAL TAMIL / ENGLISH TRANSLATOR
// ==========================================
let currentLang = 'en';

const langDict = {
  ta: {
    subbrand: "உச்ச நீதிமன்றத்தால் பாதுகாக்கப்பட்ட குட் சமாரிட்டன் சட்டப்பாதுகாப்பு",
    tabBystander: "உதவுபவர் பார்வை",
    tabHospital: "அவசர சிகிச்சை பிரிவு",
    audioOn: "ஆடியோ: ON",
    audioOff: "ஆடியோ: OFF",
    dispatchBtn: "REAPERSHIELD-ஐ இயக்கு & சட்டப்பாதுகாப்பு பெறு",
    dispatchedBtn: "சட்டப்பாதுகாப்பு இயக்கப்பட்டது (ஆஸ்பத்திரிக்கு தகவல்)",
    tokenStatusPending: "அலெர்ட் காத்திருக்கிறது",
    tokenStatusActive: "சட்டப்பாதுகாப்பு உடனே இயங்குகிறது • ZERO LIABILITY",
    certTitle: "குட் சமாரிட்டன் சட்டப்பாதுகாப்பு பாஸ்",
    certMandate: "சட்டப்பூர்வ உத்தரவு: உச்ச நீதிமன்ற தீர்ப்பு WP(C) 235/2012 மற்றும் மோட்டார் வாகனச் சட்டம் பிரிவு 134A-ன் படி, விபத்தில் ஒருவரைக் காப்பாற்ற வந்த இந்த நபரிடம் பணமோ, அட்மிஷன் டெபாசிட்டோ, அல்லது போலீஸ் விசாரணையோ கட்டாயப்படுத்தக் கூடாது.",
    scanVerify: "ஸ்கேன் செய்து சரிபார்க்கவும்"
  },
  en: {
    subbrand: "Supreme Court Protected Good Samaritan Legal Shield",
    tabBystander: "Bystander",
    tabHospital: "Trauma Command",
    audioOn: "Audio: ON",
    audioOff: "Audio: OFF",
    dispatchBtn: "TRIGGER REAPERSHIELD & GET IMMUNITY",
    dispatchedBtn: "LEGAL SHIELD ACTIVATED (DISPATCHED)",
    tokenStatusPending: "PENDING DISPATCH",
    tokenStatusActive: "IMMUNITY ACTIVE • ZERO LIABILITY",
    certTitle: "GOOD SAMARITAN LEGAL IMMUNITY PASS",
    certMandate: "LEGAL MANDATE: The bearer has acted in good faith to save a human life. By order of the Supreme Court of India, this individual shall not be detained, questioned without written consent, or forced to pay admission charges.",
    scanVerify: "SCAN TO VERIFY"
  }
};

function toggleLanguage() {
  currentLang = currentLang === 'en' ? 'ta' : 'en';
  document.getElementById('lang-label').innerText = currentLang === 'en' ? 'தமிழ்' : 'English';
  
  const d = langDict[currentLang];
  document.getElementById('txt-subbrand').innerText = d.subbrand;
  document.getElementById('tab-bystander-txt').innerText = d.tabBystander;
  document.getElementById('tab-hosp-txt').innerText = d.tabHospital;
  
  const audioLabel = document.getElementById('audio-label');
  if (audioLabel) {
    audioLabel.innerText = isAudioPlaying ? d.audioOn : d.audioOff;
  }

  // Update speech synthesis announcement language
  speakAnnouncement(currentLang === 'ta' ? "தமிழ் மொழிக்கு மாற்றப்பட்டுள்ளது. ரீப்பர் ஷீல்ட் சட்டப் பாதுகாப்பு தயார்." : "Switched to English. ReaperShield Legal Protection is ready.");
}

// Hook into DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
  initEkg();
  initGoldenHourTimer();
  scheduleAutoLightning();
});


// =======================================================
// 17. BLOODLINE EMERGENCY DONOR NETWORK & CHAIN OF CUSTODY
// =======================================================
let selectedBloodGroup = 'O-';

let donorsPool = [
  { 
    id: "D1", 
    name: "Karthik Raja", 
    blood: "O-", 
    phone: "+91 98401 23456", 
    occupation: "IT Systems Engineer @ TCS", 
    source: "Verified Indian Red Cross Society (Camp ID: #RC-9082)", 
    lastDonated: "4 Months ago (Medically Eligible)", 
    area: "Mount Road, Chennai", 
    distance: "1.2 km", 
    status: "Verified Active", 
    enRoute: false 
  },
  { 
    id: "D2", 
    name: "Ananya Murali", 
    blood: "O-", 
    phone: "+91 98410 87654", 
    occupation: "Senior High School Teacher", 
    source: "Rajiv Gandhi GH Annual Blood Registry (Reg #GH-2025)", 
    lastDonated: "6 Months ago (Medically Eligible)", 
    area: "Royapettah, Chennai", 
    distance: "2.1 km", 
    status: "Verified Active", 
    enRoute: false 
  },
  { 
    id: "D3", 
    name: "Venkatesh S.", 
    blood: "O+", 
    phone: "+91 94440 11223", 
    occupation: "Swiggy Emergency Fleet Partner", 
    source: "108 First Responder Community Drive", 
    lastDonated: "3 Months ago (Medically Eligible)", 
    area: "Egmore, Chennai", 
    distance: "2.8 km", 
    status: "Verified Active", 
    enRoute: false 
  },
  { 
    id: "D4", 
    name: "Dr. Deepa K.", 
    blood: "O-", 
    phone: "+91 97900 99887", 
    occupation: "Resident Medical Officer", 
    source: "Indian Medical Association (IMA) Doctors Registry", 
    lastDonated: "5 Months ago (Medically Eligible)", 
    area: "Park Town, Chennai", 
    distance: "1.5 km", 
    status: "Verified Active", 
    enRoute: false 
  },
  { 
    id: "D5", 
    name: "Suresh Balaji", 
    blood: "B+", 
    phone: "+91 98840 55667", 
    occupation: "Banking Analyst (SBI)", 
    source: "Rotary Club Blood Bank Portal", 
    lastDonated: "4 Months ago (Medically Eligible)", 
    area: "T. Nagar, Chennai", 
    distance: "3.2 km", 
    status: "Verified Active", 
    enRoute: false 
  },
  { 
    id: "D6", 
    name: "Pooja Ramesh", 
    blood: "A+", 
    phone: "+91 98409 33221", 
    occupation: "Civil Services Aspirant", 
    source: "University Blood Samaritan Chapter", 
    lastDonated: "5 Months ago (Medically Eligible)", 
    area: "Triplicane, Chennai", 
    distance: "1.9 km", 
    status: "Verified Active", 
    enRoute: false 
  }
];

function selectBloodGroup(bg) {
  selectedBloodGroup = bg;
  const groups = ['O-', 'O+', 'A+', 'B+', 'AB+'];
  groups.forEach(g => {
    const btn = document.getElementById(`bg-${g}`);
    if (btn) {
      if (g === bg) {
        btn.className = "py-1 px-1 rounded border border-fuchsia-500 bg-fuchsia-950/80 text-fuchsia-200 text-[10px] font-bold shadow-[0_0_12px_rgba(217,70,239,0.5)]";
      } else {
        btn.className = "py-1 px-1 rounded border border-purple-500/30 bg-purple-950/40 text-purple-300 text-[10px] font-bold hover:bg-purple-900/50 transition-all";
      }
    }
  });

  const note = document.getElementById('blood-dispatch-note');
  if (note) {
    const matched = getCompatibleDonors(bg);
    note.innerText = `● Selecting ${bg} matches ${matched.length} verified donors within 3.5 km with complete occupational & collection verification.`;
  }
}

// Blood compatibility logic
function getCompatibleDonors(patientBlood) {
  return donorsPool.filter(donor => {
    if (patientBlood === 'O-') return donor.blood === 'O-';
    if (patientBlood === 'O+') return donor.blood === 'O-' || donor.blood === 'O+';
    if (patientBlood === 'A+') return donor.blood === 'O-' || donor.blood === 'O+' || donor.blood === 'A+' || donor.blood === 'A-';
    if (patientBlood === 'B+') return donor.blood === 'O-' || donor.blood === 'O+' || donor.blood === 'B+' || donor.blood === 'B-';
    if (patientBlood === 'AB+') return true; // Universal recipient
    return donor.blood === patientBlood;
  });
}

function openDonorModal() {
  const modal = document.getElementById('donor-modal');
  modal.classList.toggle('hidden');
  if (!modal.classList.contains('hidden')) {
    renderDonorsList();
  }
}

function switchDonorSubTab(tab) {
  const btnMatch = document.getElementById('donor-tab-match');
  const btnReg = document.getElementById('donor-tab-reg');
  const viewMatch = document.getElementById('donor-view-match');
  const viewReg = document.getElementById('donor-view-reg');

  if (tab === 'match') {
    btnMatch.className = "px-3 py-1.5 rounded-lg bg-rose-600 text-white font-bold transition-all";
    btnReg.className = "px-3 py-1.5 rounded-lg text-slate-400 hover:text-white transition-all";
    viewMatch.classList.remove('hidden');
    viewReg.classList.add('hidden');
    renderDonorsList();
  } else {
    btnReg.className = "px-3 py-1.5 rounded-lg bg-rose-600 text-white font-bold transition-all";
    btnMatch.className = "px-3 py-1.5 rounded-lg text-slate-400 hover:text-white transition-all";
    viewReg.classList.remove('hidden');
    viewMatch.classList.add('hidden');
  }
}

function renderDonorsList() {
  const targetLabel = document.getElementById('modal-blood-target');
  if (targetLabel) targetLabel.innerText = `${selectedBloodGroup} (Target Need)`;

  const container = document.getElementById('donors-list');
  if (!container) return;
  container.innerHTML = "";

  const matches = getCompatibleDonors(selectedBloodGroup);

  if (matches.length === 0) {
    container.innerHTML = `<div class="p-4 text-center text-slate-400 font-mono text-xs">No local donors found for ${selectedBloodGroup}. Expand radius.</div>`;
    return;
  }

  matches.forEach(donor => {
    const item = document.createElement('div');
    item.className = "p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1.5";
    
    item.innerHTML = `
      <div class="flex items-start justify-between gap-2">
        <div class="flex items-center space-x-2.5">
          <span class="w-9 h-9 rounded-xl bg-rose-950 border border-rose-500/60 flex items-center justify-center font-bold text-rose-300 text-sm shrink-0 shadow-md">
            ${donor.blood}
          </span>
          <div>
            <div class="flex items-center space-x-2">
              <p class="font-bold text-white text-xs">${donor.name}</p>
              <span class="text-[9px] px-1.5 py-0.2 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300 font-mono">
                ${donor.occupation}
              </span>
            </div>
            <p class="text-[10px] text-slate-400 font-mono mt-0.5">
              <i class="fa-solid fa-location-dot text-rose-400 mr-1"></i>${donor.area} • <strong class="text-white">${donor.distance}</strong> away
            </p>
          </div>
        </div>

        <div class="text-right shrink-0">
          <span id="donor-status-${donor.id}" class="text-[9px] font-mono px-2 py-0.5 rounded-full ${donor.enRoute ? 'bg-emerald-950 text-emerald-400 border border-emerald-500' : 'bg-slate-800 text-slate-300'}">
            ${donor.enRoute ? 'EN ROUTE (11m)' : donor.status}
          </span>
          <button type="button" onclick="sendDirectDonorPing('${donor.name}', '${donor.phone}')" class="block text-[10px] text-cyan-400 hover:underline mt-1 font-mono">
            <i class="fa-brands fa-whatsapp text-emerald-400 mr-0.5"></i> Direct WhatsApp
          </button>
        </div>
      </div>

      <!-- Provenance & Collection Verification Details -->
      <div class="grid grid-cols-2 gap-2 bg-black/60 p-2 rounded-lg border border-white/5 text-[9px] font-mono">
        <div>
          <span class="text-slate-400 block"><i class="fa-solid fa-certificate text-amber-400 mr-1"></i>Source &amp; Verification:</span>
          <span class="text-slate-200 font-semibold">${donor.source}</span>
        </div>
        <div>
          <span class="text-slate-400 block"><i class="fa-solid fa-clock-rotate-left text-cyan-400 mr-1"></i>Last Donation / Medical:</span>
          <span class="text-emerald-400 font-semibold">${donor.lastDonated}</span>
        </div>
      </div>
    `;
    container.appendChild(item);
  });
}

function broadcastDonorAlert() {
  const btn = document.getElementById('btn-broadcast-alert');
  btn.disabled = true;
  btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-1.5"></i> BROADCASTING AWS SNS EMERGENCY SMS...`;

  setTimeout(() => {
    const matches = getCompatibleDonors(selectedBloodGroup);
    matches.forEach(d => {
      d.status = "🚨 SMS / WHATSAPP SENT";
      const statusSpan = document.getElementById(`donor-status-${d.id}`);
      if (statusSpan) {
        statusSpan.className = "text-[9px] font-mono px-2 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-500 animate-pulse";
        statusSpan.innerText = "ALERT DISPATCHED";
      }
    });

    btn.disabled = false;
    btn.innerHTML = `<i class="fa-solid fa-check text-emerald-400 mr-1.5"></i> <span>ALERTS SENT TO ${matches.length} DONORS (WAITING ACCEPTANCE)</span>`;

    // Simulate 1 donor accepting within 2 seconds
    setTimeout(() => {
      if (matches.length > 0) {
        matches[0].enRoute = true;
        matches[0].status = "ACCEPTED - EN ROUTE";
        const statusSpan = document.getElementById(`donor-status-${matches[0].id}`);
        if (statusSpan) {
          statusSpan.className = "text-[9px] font-mono px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500 font-bold glow-cyan";
          statusSpan.innerText = "ACCEPTED - EN ROUTE (ETA 11m)";
        }
        
        // Voice Alert
        speakAnnouncement(`Emergency blood donor ${matches[0].name} accepted alert. En route to trauma room with blood group ${matches[0].blood}.`);
        
        alert(`🚨 DONOR ACCEPTANCE CONFIRMED!

${matches[0].name} (${matches[0].blood}) is en route to Rajiv Gandhi General Hospital!
ETA: 11 Minutes.`);
      }
    }, 2200);

  }, 1000);
}

function sendDirectDonorPing(name, phone) {
  const msg = encodeURIComponent(`🚨 EMERGENCY BLOOD ALERT (ReaperShield):
Patient requires ${selectedBloodGroup} at Rajiv Gandhi Trauma Center.
Can you respond immediately?`);
  window.open(`https://api.whatsapp.com/send?phone=${phone.replace(/[^0-9]/g, '')}&text=${msg}`, '_blank');
}

function handleDonorRegistration(event) {
  event.preventDefault();
  const name = document.getElementById('reg-donor-name').value.trim();
  const blood = document.getElementById('reg-donor-blood').value;
  const phone = document.getElementById('reg-donor-phone').value.trim();
  const area = document.getElementById('reg-donor-area').value.trim();
  const occupation = document.getElementById('reg-donor-occupation').value.trim() || "Independent Professional";
  const source = document.getElementById('reg-donor-source').value.trim() || "ReaperShield Digital Self-Registration";
  const lastDonated = document.getElementById('reg-donor-lastdonation').value.trim() || "Eligible (Screened)";

  const newId = `D${donorsPool.length + 1}`;
  donorsPool.unshift({
    id: newId,
    name: name,
    blood: blood,
    phone: phone,
    occupation: occupation,
    source: source,
    lastDonated: lastDonated,
    area: area,
    distance: "0.8 km",
    status: "Verified Active",
    enRoute: false
  });

  // Update badge count
  const badge = document.getElementById('badge-donors-count');
  if (badge) badge.innerText = donorsPool.length;

  alert(`🎉 Thank you, ${name} (${occupation})!
You are successfully registered via ${source}.
You will receive instant emergency SMS alerts whenever someone nearby requires ${blood} blood.`);
  
  // Switch to match tab
  switchDonorSubTab('match');
}


// ========================================================
// 18. GOOGLE GEMINI 3.1 AI TRUTH & ALL-TOPIC FIRST-AID ENGINE
// (Full 100% Coverage of All 12 Chapters in 2026 Handbook)
// ========================================================
// Use the local Python API during development. For a deployed API, set
// window.REAPERSHIELD_API_BASE before this script is loaded.
const API_BASE = window.REAPERSHIELD_API_BASE || (
  window.location.protocol === 'file:' ||
  window.location.hostname === 'localhost' ||
  window.location.hostname === '127.0.0.1'
    ? 'http://localhost:8000'
    : ''
);

let lastGeminiTriage = null;
let currentSpeechUtterance = null;

const FIRST_AID_PRESETS = {
  'cpr_adult': {
    sev: 'critical',
    title: "💓 Adult CPR & AED",
    text: "Adult victim collapsed, unresponsive, not breathing and no pulse detected. Need emergency CPR instructions."
  },
  'severe_choking': {
    sev: 'critical',
    title: "🗣️ Adult Choking (Heimlich)",
    text: "Adult victim clutching throat, unable to breathe, cough or speak. Silent choking, turning blue."
  },
  'choking_baby': {
    sev: 'critical',
    title: "👶 Baby Choking (<1 yr)",
    text: "Infant / baby under 1 year old choking on a small toy piece, silent, cannot cry or breathe."
  },
  'severe_bleeding': {
    sev: 'critical',
    title: "🩸 Severe Bleeding & Tourniquet",
    text: "Deep cut on forearm with spurting dark-red blood, soaked through multiple cloth towels, pale and dizzy."
  },
  'nosebleed': {
    sev: 'moderate',
    title: "👃 Nosebleed (Lean Forward)",
    text: "Victim suffering heavy nosebleed after blunt face impact, blood dripping continuously from nostrils."
  },
  'thermal_burn': {
    sev: 'critical',
    title: "🔥 20-Min Burn Flush",
    text: "Victim suffering severe boiling radiator water burn on both arms and chest with large blisters, in extreme agony."
  },
  'chemical_splash': {
    sev: 'critical',
    title: "🧪 Chemical in Eye / Skin",
    text: "Acid battery chemical liquid splashed directly into worker's left eye and facial skin, severe burning pain."
  },
  'bone_fracture': {
    sev: 'critical',
    title: "🦴 Broken Bone / Fracture",
    text: "Pedestrian hit by car, severe deformity and unnatural angle on lower leg, bone protruding under skin, cannot move."
  },
  'heart_attack': {
    sev: 'critical',
    title: "🫀 Chest Pain / Heart Attack",
    text: "Driver clutched chest with crushing pressure spreading to left arm & jaw, cold sweat, gasping for breath."
  },
  'stroke_fast': {
    sev: 'critical',
    title: "🧠 Stroke (FAST)",
    text: "Elderly pedestrian face drooping on right side, right arm weak and numb, slurred unintelligible speech."
  },
  'seizure_fit': {
    sev: 'critical',
    title: "⚡ Seizure / Fits (No Spoons)",
    text: "Person collapsed having violent full-body jerking convulsions and seizure on road, foaming at mouth, unconscious."
  },
  'snake_bite': {
    sev: 'critical',
    title: "🐍 Snakebite (No Cut/Suck)",
    text: "Bitten on ankle by a dark snake in roadside bushes, swelling rapidly, puncture fang marks visible, person anxious."
  },
  'animal_bite': {
    sev: 'moderate',
    title: "🐕 Dog Bite (15-Min Soap Wash)",
    text: "Stray dog bite on leg with bleeding puncture tears and saliva exposure, conscious and walking."
  },
  'electric_shock': {
    sev: 'critical',
    title: "⚡ Electric Shock (Mains Off)",
    text: "Construction worker touched exposed live power wire, collapsed near sparking cable, unmoving."
  },
  'drowning_rescue': {
    sev: 'critical',
    title: "🤿 Drowning Rescue",
    text: "Person pulled from lake water, unconscious and not breathing, water in mouth."
  },
  'asthma_attack': {
    sev: 'moderate',
    title: "🫁 Asthma Attack",
    text: "Young person experiencing severe asthma attack, wheezing loudly, struggling to inhale, inhaler empty."
  },
  'low_sugar': {
    sev: 'moderate',
    title: "🍬 Low Sugar / Diabetes",
    text: "Diabetic patient shaky, sweating excessively, confused, slurred speech, took insulin but skipped meal."
  },
  'poisoning_toxic': {
    sev: 'critical',
    title: "☠️ Poisoning (No Vomiting)",
    text: "Person accidentally drank household chemical pesticide cleaner, burning throat, chemical container found beside them."
  },
  'fainting_collapse': {
    sev: 'minor',
    title: "😵 Fainting (Raise Legs 30cm)",
    text: "Person suddenly fainted under direct hot sun, brief loss of consciousness, slowly waking up on ground."
  },
  'head_bleed': {
    sev: 'critical',
    title: "💥 Crash (DO NOT Remove Helmet)",
    text: "Unconscious motorcyclist with heavy bleeding from skull on pavement, wearing helmet. Shallow breathing."
  },
  'spinal_fall': {
    sev: 'critical',
    title: "💥 Spinal Trauma",
    text: "Victim thrown off vehicle, severe cervical neck & back agony, tingling sensation in legs, suspect spinal cord fracture."
  },
  'prank_test': {
    sev: 'minor',
    title: "🎭 Prank / Hoax Test",
    text: "Haha just testing this app for fun, my friend slipped on a banana peel playing a prank."
  }
};

// Smooth navigation to AI Diagnostic Hub
function scrollToAiTriage() {
  const hub = document.getElementById('ai-triage-hub');
  if (hub) {
    hub.scrollIntoView({ behavior: 'smooth', block: 'start' });
    const queryInput = document.getElementById('hub-ai-query');
    if (queryInput) {
      setTimeout(() => {
        queryInput.focus();
        queryInput.classList.add('border-fuchsia-400', 'shadow-[0_0_30px_rgba(217,70,239,0.8)]');
        setTimeout(() => queryInput.classList.remove('shadow-[0_0_30px_rgba(217,70,239,0.8)]'), 1200);
      }, 500);
    }
  }
}

// Handler for Asking AI via Top Dedicated Hub
function askGeminiHub() {
  const queryInput = document.getElementById('hub-ai-query');
  const query = queryInput ? queryInput.value.trim() : '';
  if (!query) {
    if (queryInput) {
      queryInput.placeholder = "⚠️ Please type a question or click any topic chip below!";
      queryInput.focus();
    }
    return;
  }
  askGeminiFirstAid(query, 'hub');
}

// Handler for Clicking any Preset in Top Hub
function askGeminiPreset(presetId) {
  const preset = FIRST_AID_PRESETS[presetId];
  if (!preset) return;

  const queryInput = document.getElementById('hub-ai-query');
  if (queryInput) queryInput.value = preset.text;

  const notesInput = document.getElementById('victim-notes-input');
  if (notesInput) notesInput.value = preset.text;

  if (typeof selectSeverity === 'function') {
    selectSeverity(preset.sev);
  }

  askGeminiFirstAid(preset.text, 'hub');
}

// Handler for Dispatch Form Chips
function setVictimPreset(type) {
  askGeminiPreset(type);
  const formPanel = document.getElementById('emergency-form');
  if (formPanel) {
    formPanel.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

// Core Unified AI Triage Request
async function askGeminiFirstAid(notesText, source = 'hub') {
  const hubAskBtn = document.getElementById('btn-hub-ask');
  const hubBtnTxt = document.getElementById('txt-hub-ask-btn');
  const dispatchBtn = document.getElementById('btn-gemini-triage');
  const dispatchBtnTxt = document.getElementById('txt-gemini-btn');

  if (hubAskBtn) hubAskBtn.disabled = true;
  if (hubBtnTxt) hubBtnTxt.innerText = "THINKING...";
  if (dispatchBtn) dispatchBtn.disabled = true;
  if (dispatchBtnTxt) dispatchBtnTxt.innerText = "🤖 GEMINI AI ANALYZING FIRST-AID...";

  const loc = document.getElementById('incident-location') ? document.getElementById('incident-location').value : "Anna Salai, Chennai";
  const sev = selectedSeverity || "CRITICAL";
  const bg = selectedBloodGroup || "O-";

  const payload = {
    location: loc,
    severity: sev,
    blood_group: bg,
    victim_notes: notesText || "General Emergency First Aid Priorities and Scene Safety"
  };

  let resultData = null;

  try {
    const response = await fetch(`${API_BASE}/api/gemini/triage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`Server returned HTTP ${response.status}`);
    }

    resultData = await response.json();
  } catch (err) {
    console.warn("Using high-accuracy client-side First Aid Knowledge Base engine:", err);
    resultData = getClientSideClinicalTriage(notesText, loc);
  } finally {
    if (hubAskBtn) hubAskBtn.disabled = false;
    if (hubBtnTxt) hubBtnTxt.innerText = "ASK AI";
    if (dispatchBtn) dispatchBtn.disabled = false;
    if (dispatchBtnTxt) dispatchBtnTxt.innerText = "🤖 GEMINI AI: VERIFY TRUTH & GET FIRST-AID GUIDE";
  }

  lastGeminiTriage = resultData;
  renderTriageData(resultData, source);
}

// Legacy Dispatch Button Adapter
function runGeminiAiTriage() {
  const notesInput = document.getElementById('victim-notes-input');
  const notes = notesInput ? notesInput.value.trim() : '';
  askGeminiFirstAid(notes || "General Emergency First Aid Priorities and Scene Safety", 'form');
}

// Unified Renderer for Both Top Hub and Bottom Dispatch Card
function renderTriageData(data, source = 'hub') {
  if (!data) return;

  // 1. Update Top Dedicated Hub Elements
  const hubProtocol = document.getElementById('hub-matched-protocol');
  if (hubProtocol) hubProtocol.innerText = `📋 ${data.matched_protocol || 'Protocol 1: General Emergency Care'}`;

  const hubAuthBadge = document.getElementById('hub-auth-badge');
  const hubAuthTag = document.getElementById('hub-auth-tag');
  const hubAuthReason = document.getElementById('hub-auth-rationale');

  if (hubAuthBadge) {
    if (data.is_authentic) {
      hubAuthBadge.className = "px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950 border border-emerald-500 text-emerald-300";
      hubAuthBadge.innerText = `✅ ${data.authenticity_score || 98}% AUTHENTIC MEDICAL EMERGENCY`;
      if (hubAuthTag) {
        hubAuthTag.className = "text-emerald-400 font-bold";
        hubAuthTag.innerText = "AUTHENTIC EMERGENCY";
      }
    } else {
      hubAuthBadge.className = "px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950 border border-amber-500 text-amber-300 animate-pulse";
      hubAuthBadge.innerText = `⚠️ POTENTIAL HOAX / PRANK (${data.authenticity_score || 15}%)`;
      if (hubAuthTag) {
        hubAuthTag.className = "text-amber-400 font-bold";
        hubAuthTag.innerText = "FLAGGED AS SUSPICIOUS / HOAX";
      }
    }
  }
  if (hubAuthReason) {
    hubAuthReason.innerText = data.authenticity_rationale || "Clinical verification completed.";
  }

  const hubVerdictPill = document.getElementById('hub-verdict-pill');
  if (hubVerdictPill) {
    if (data.should_give_first_aid) {
      hubVerdictPill.className = "inline-block px-3.5 py-1 rounded-full text-xs font-mono font-extrabold bg-emerald-950 border border-emerald-400 text-emerald-300 shadow";
      hubVerdictPill.innerText = "✅ SHOULD YOU GIVE FIRST AID: YES (FOLLOW OFFICIAL PROTOCOL)";
    } else {
      hubVerdictPill.className = "inline-block px-3.5 py-1 rounded-full text-xs font-mono font-extrabold bg-red-950 border border-red-500 text-red-300 shadow animate-pulse";
      hubVerdictPill.innerText = "⛔ SHOULD YOU GIVE FIRST AID: STRICTLY DO NOT TOUCH VICTIM";
    }
  }

  const hubHeadline = document.getElementById('hub-decision-headline');
  if (hubHeadline) {
    hubHeadline.innerText = data.decision_headline || "FOLLOW CLINICAL FIRST AID DIRECTIONS";
  }

  const hubDoNots = document.getElementById('hub-critical-do-nots');
  if (hubDoNots) {
    hubDoNots.innerHTML = (data.critical_do_nots || [
      "DO NOT put yourself in danger before approaching the scene.",
      "DO NOT give food, water, or oral tablets to an unconscious person."
    ]).map(d => `<li>${d}</li>`).join('');
  }

  const hubActions = document.getElementById('hub-safe-actions');
  if (hubActions) {
    hubActions.innerHTML = (data.safe_action_steps || [
      "Ensure scene safety and call 108/112 immediately on speaker.",
      "Check responsiveness and normal breathing."
    ]).map(a => `<li>${a}</li>`).join('');
  }

  const hubTamil = document.getElementById('hub-tamil-audio');
  if (hubTamil && data.tamil_audio_guide) {
    hubTamil.innerText = data.tamil_audio_guide;
  }

  const hubBriefing = document.getElementById('hub-operator-briefing');
  if (hubBriefing && data.operator_briefing) {
    hubBriefing.innerText = data.operator_briefing;
  }

  // 2. Synchronize Bottom Form Panel
  const formPanel = document.getElementById('gemini-triage-panel');
  if (formPanel) {
    formPanel.classList.remove('hidden');

    const formAuthBadge = document.getElementById('gemini-auth-badge');
    if (formAuthBadge) {
      formAuthBadge.className = data.is_authentic 
        ? "px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950 border border-emerald-500 text-emerald-300"
        : "px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950 border border-amber-500 text-amber-300 animate-pulse";
      formAuthBadge.innerText = data.is_authentic ? `✅ ${data.authenticity_score || 96}% AUTHENTIC` : `⚠️ POTENTIAL HOAX (${data.authenticity_score || 15}%)`;
    }

    const formVerdict = document.getElementById('gemini-verdict-pill');
    if (formVerdict) {
      formVerdict.className = data.should_give_first_aid
        ? "inline-block px-3 py-1 rounded-md text-xs font-mono font-bold bg-emerald-950 border border-emerald-400 text-emerald-300 shadow"
        : "inline-block px-3 py-1 rounded-md text-xs font-mono font-bold bg-red-950 border border-red-500 text-red-300 shadow animate-pulse";
      formVerdict.innerText = data.should_give_first_aid
        ? "✅ SHOULD YOU GIVE FIRST AID: YES"
        : "⛔ SHOULD YOU GIVE FIRST AID: STRICTLY DO NOT TOUCH VICTIM";
    }

    const formHeadline = document.getElementById('gemini-decision-headline');
    if (formHeadline) formHeadline.innerText = `DECISION: ${data.decision_headline}`;

    const formDoNots = document.getElementById('gemini-do-nots');
    if (formDoNots) {
      formDoNots.innerHTML = (data.critical_do_nots || []).map(d => `<li>${d}</li>`).join('');
    }

    const formActions = document.getElementById('gemini-action-steps');
    if (formActions) {
      formActions.innerHTML = (data.safe_action_steps || []).map(a => `<li>${a}</li>`).join('');
    }

    const formProtocol = document.getElementById('gemini-protocol-badge');
    if (formProtocol) formProtocol.innerText = `📋 ${data.matched_protocol}`;

    const formTamil = document.getElementById('gemini-tamil-text');
    if (formTamil) formTamil.innerText = data.tamil_audio_guide || '';

    const formBriefing = document.getElementById('gemini-operator-briefing');
    if (formBriefing) formBriefing.innerText = data.operator_briefing || '';
  }

  // 3. Audio Voice Announcement (Tamil or English)
  playTamilVoiceGuide();

  // 4. Smooth Scroll to Active Panel
  if (source === 'hub') {
    const hubPanel = document.getElementById('hub-result-panel');
    if (hubPanel) hubPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  } else {
    if (formPanel) formPanel.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

// Spoken Voice Guide Engine via Web Speech API
function playTamilVoiceGuide() {
  if (!('speechSynthesis' in window)) return;
  stopVoiceGuide();

  const text = (lastGeminiTriage && lastGeminiTriage.tamil_audio_guide)
    ? lastGeminiTriage.tamil_audio_guide
    : (lastGeminiTriage ? `${lastGeminiTriage.decision_headline}. ${lastGeminiTriage.safe_action_steps ? lastGeminiTriage.safe_action_steps[0] : ''}` : "Emergency first aid guidance loaded.");

  currentSpeechUtterance = new SpeechSynthesisUtterance(text);
  
  // Attempt Tamil language synthesis, otherwise default
  const voices = window.speechSynthesis.getVoices();
  const tamilVoice = voices.find(v => v.lang.startsWith('ta') || v.name.toLowerCase().includes('tamil'));
  if (tamilVoice) {
    currentSpeechUtterance.voice = tamilVoice;
    currentSpeechUtterance.lang = 'ta-IN';
  } else {
    currentSpeechUtterance.rate = 0.95;
  }

  window.speechSynthesis.speak(currentSpeechUtterance);
}

function stopVoiceGuide() {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

function speakGeminiInstruction() {
  playTamilVoiceGuide();
}

function copyHubOperatorBriefing() {
  const briefing = document.getElementById('hub-operator-briefing');
  const text = briefing ? briefing.innerText : '';
  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).then(() => {
      alert("📋 112/108 Ambulance Operator Briefing copied to clipboard!\n\nYou can read or paste this directly during your emergency call.");
    });
  } else {
    prompt('Copy 112/108 Ambulance Briefing:', text);
  }
}

// Complete 18-Condition Client-Side Rule Engine (Ensures 100% Offline / Failure-Proof Reliability)
function getClientSideClinicalTriage(notes, location = "Anna Salai, Chennai") {
  const n = (notes || "").toLowerCase();

  // 0. Prank Check
  if (anyWord(n, ['test', 'prank', 'joke', 'ghost', 'fake', 'fool', 'பரிகாசம்', 'விளையாட்டு'])) {
    return {
      is_authentic: false,
      authenticity_score: 15,
      authenticity_rationale: "Forensic Discrepancy: Observation notes contain non-clinical test or prank indicators.",
      matched_protocol: "Section 1: False Alarm & Hoax Filter",
      should_give_first_aid: false,
      decision_headline: "SUSPECTED HOAX / FALSE ALARM • NO CLINICAL INTERVENTION REQUIRED",
      critical_do_nots: [
        "DO NOT mobilize emergency ambulance response teams for unverified prank reports.",
        "DO NOT tamper with emergency dispatch channels."
      ],
      safe_action_steps: [
        "Verify physical scene before triggering emergency beacons.",
        "If a real medical emergency exists, describe specific physical symptoms."
      ],
      tamil_audio_guide: "இது உண்மையான அவசர உதவி போல் தெரியவில்லை. உண்மையான விபத்து என்றால் காயத்தின் விவரங்களை சரியாக பதிவிடவும்.",
      operator_briefing: "Unconfirmed report flagged as probable false alarm."
    };
  }

  // 1. Choking Protocol (Adult & Infant < 1 yr)
  if (anyWord(n, ['chok', 'throat', 'swallow', 'airway', 'heimlich', 'அடைப்பு', 'மூச்சுத்திணறல்', 'தொண்டை'])) {
    const isInfant = anyWord(n, ['baby', 'infant', 'குழந்தை', 'குழந்தைக்கு', '<1']);
    if (isInfant) {
      return {
        is_authentic: true,
        authenticity_score: 99,
        authenticity_rationale: "Severe infant foreign-body airway obstruction (Protocol 3).",
        matched_protocol: "Protocol 3: Severe Choking in Infants (< 1 Year)",
        should_give_first_aid: true,
        decision_headline: "5 BACK BLOWS & 5 CHEST THRUSTS • STRICTLY NO HEIMLICH FOR INFANTS",
        critical_do_nots: [
          "DO NOT perform abdominal thrusts (Heimlich maneuver) on an infant under 1 year (ruptures liver/spleen).",
          "DO NOT perform blind finger sweeps in infant's mouth (forces foreign object deeper into airway)."
        ],
        safe_action_steps: [
          "Lay infant face down along your forearm resting on your thigh, head supported and lower than chest.",
          "Deliver up to 5 firm, distinct back slaps between shoulder blades using heel of your hand.",
          "If still blocked, turn infant face up along your other forearm; give up to 5 chest thrusts with 2 fingers on breastbone.",
          "Repeat 5 back blows and 5 chest thrusts; if infant becomes unresponsive, call 108 immediately and begin CPR."
        ],
        tamil_audio_guide: "1 வயதுக்கு உட்பட்ட குழந்தைக்கு வயிற்றை அழுத்தக்கூடாது! குழந்தையை உங்கள் கையில் குப்புற படுக்க வைத்து, தலை கீழ்நோக்கி இருக்கும்படி முதுகில் 5 முறை தட்டவும். அடைப்பு நீங்காவிட்டால் மார்பில் 2 விரல்களால் 5 முறை அழுத்தவும்.",
        operator_briefing: `Critical infant choking at ${location}. Baby under 1 year. Back blows/chest thrusts active. Immediate pediatric paramedic dispatched needed.`
      };
    } else {
      return {
        is_authentic: true,
        authenticity_score: 99,
        authenticity_rationale: "Complete adult foreign-body airway obstruction (Protocol 3).",
        matched_protocol: "Protocol 3: Severe Choking in Adults & Children Over 1 Year",
        should_give_first_aid: true,
        decision_headline: "ALTERNATE 5 BACK BLOWS AND 5 ABDOMINAL THRUSTS (HEIMLICH)",
        critical_do_nots: [
          "DO NOT perform blind finger sweeps without seeing the object.",
          "DO NOT offer water or food to a choking victim.",
          "DO NOT slap a person on the back while they are standing completely upright (gravity drops object deeper)."
        ],
        safe_action_steps: [
          "Encourage coughing if person can speak or cough forcefully.",
          "If silent/unable to breathe: stand behind them, lean person well forward, deliver 5 firm back blows between shoulder blades.",
          "If unresolved: place fist thumb-side in above navel, grasp with other hand, pull sharply inward and upward 5 times.",
          "Alternate 5 back blows and 5 abdominal thrusts until object clears or person collapses into CPR."
        ],
        tamil_audio_guide: "பாதிக்கப்பட்டவரை முன்னால் சாய்த்து முதுகில் 5 முறை பலமாக தட்டவும். அடைப்பு நீங்காவிட்டால், தொப்புளுக்கு சற்று மேலே கையை மடக்கி பிடித்து உள்நோக்கியும் மேல்நோக்கியும் 5 முறை அழுத்தவும் (ஹெய்ம்லிச் முறை).",
        operator_briefing: `Complete choking emergency at ${location}. Adult Heimlich maneuver in progress. Airway compromised.`
      };
    }
  }

  // 2. CPR & Cardiac Arrest
  if (anyWord(n, ['cpr', 'cardiac', 'unresponsive', 'not breathing', 'no pulse', 'நினைவில்லை', 'சுயநினைவு', 'மார்பு அழுத்தம்', 'இதய துடிப்பு'])) {
    return {
      is_authentic: true,
      authenticity_score: 99,
      authenticity_rationale: "Unresponsive non-breathing casualty: Out-of-hospital cardiac arrest (Protocol 2).",
      matched_protocol: "Protocol 2: CPR, Choking & Unconsciousness",
      should_give_first_aid: true,
      decision_headline: "START IMMEDIATE HANDS-ONLY CPR • PUSH HARD & FAST (100-120 BPM)",
      critical_do_nots: [
        "DO NOT delay CPR to search for a pulse if person is unresponsive and not breathing normally.",
        "DO NOT stop chest compressions until ambulance paramedics take over or AED is analyzing.",
        "DO NOT lean on casualty's chest between compressions; allow full elastic chest recoil."
      ],
      safe_action_steps: [
        "Place casualty on their back on a hard, firm, flat floor and call 108 on speakerphone immediately.",
        "Place heel of one hand in exact center of chest (lower half of sternum), interlock fingers with other hand.",
        "Lock elbows straight, push down hard 5-6 cm at 100-120 compressions per minute (to beat of 'Stayin Alive').",
        "If AED is available, turn it on immediately and follow its automated voice prompts."
      ],
      tamil_audio_guide: "பதற்றமடைய வேண்டாம். உடனடியாக 108 அழைக்கவும். பாதிக்கப்பட்டவரை சமமான தரையில் மல்லாக்க படுக்க வைத்து, மார்பின் நடுவில் கைகளை வைத்து நிமிடத்திற்கு 100 முதல் 120 முறை வேகமாக, ஆழமாக அழுத்தவும்.",
      operator_briefing: `Cardiac arrest at ${location}. Bystander hands-only CPR in progress. Defibrillator required.`
    };
  }

  // 3. Heart Attack / Chest Pain
  if (anyWord(n, ['heart attack', 'chest pain', 'crushing chest', 'நெஞ்சு வலி', 'மாரடைப்பு', 'நெஞ்சு'])) {
    return {
      is_authentic: true,
      authenticity_score: 98,
      authenticity_rationale: "Acute coronary syndrome / suspected myocardial infarction (Protocol 7).",
      matched_protocol: "Protocol 7: Medical Emergencies - Heart Attack",
      should_give_first_aid: true,
      decision_headline: "SEAT IN W-POSITION • CHEW 300MG ASPIRIN IF NOT ALLERGIC • CALL 108",
      critical_do_nots: [
        "DO NOT let person walk, climb stairs, or exert themselves.",
        "DO NOT give aspirin if person is allergic, under 16, or has active stomach ulcers.",
        "DO NOT drive the person yourself if an ambulance with ECG/defibrillator is available."
      ],
      safe_action_steps: [
        "Sit person on floor leaning against a wall with knees bent and supported ('W-position').",
        "Call 108 immediately and inform dispatcher: 'Suspected acute heart attack'.",
        "If conscious and non-allergic, have them chew one 300mg soluble aspirin tablet slowly.",
        "Loosen tight collar, belt and clothing; monitor breathing continuously and prepare for CPR if they collapse."
      ],
      tamil_audio_guide: "மார்பு வலித்தால் நடக்க விடாதீர்கள். சுவரில் சாய்ந்து முழங்கால்களை மடக்கி 'W' நிலையில் அமர வையுங்கள். 108 அழைக்கவும். அலர்ஜி இல்லாவிட்டால் ஆஸ்பிரின் 300mg மாத்திரையை மென்று விழுங்கச் சொல்லலாம்.",
      operator_briefing: `Suspected acute myocardial infarction at ${location}. Patient in W-position. Aspirin administered.`
    };
  }

  // 4. Stroke (F.A.S.T.)
  if (anyWord(n, ['stroke', 'paralysis', 'slurred', 'face droop', 'fast', 'பக்கவாதம்', 'வாய் கோணல்', 'கை பலவீனம்'])) {
    return {
      is_authentic: true,
      authenticity_score: 99,
      authenticity_rationale: "Acute cerebrovascular accident / Stroke symptoms (Protocol 7).",
      matched_protocol: "Protocol 7: Medical Emergencies - Stroke (FAST)",
      should_give_first_aid: true,
      decision_headline: "STROKE FAST ALERT • NOTE EXACT ONSET TIME • CALL 108/112 IMMEDIATELY",
      critical_do_nots: [
        "DO NOT give food, drink, water or medication (swallowing reflex may be paralyzed, causing choking/aspiration).",
        "DO NOT give aspirin (if stroke is hemorrhagic, aspirin causes fatal bleeding into brain).",
        "DO NOT wait to see if symptoms improve; brain cells die every minute."
      ],
      safe_action_steps: [
        "Check F.A.S.T.: Face drooping? Arm weakness? Slurred speech? Time to call 108!",
        "Note the EXACT minute symptoms were first observed (critical for 4.5-hour thrombolytic clot-buster window).",
        "Keep person lying comfortably with head and shoulders slightly elevated.",
        "If unconscious or vomiting, turn gently onto their side into recovery position to keep airway clear."
      ],
      tamil_audio_guide: "பக்கவாதம் ஏற்பட்டவருக்கு தண்ணீர், உணவு அல்லது ஆஸ்பிரின் மாத்திரை கொடுக்கவே கூடாது! முகம் கோணல், கை பலவீனம், பேச்சு குழறல் உள்ளதா என பார்த்து அறிகுறிகள் தொடங்கிய நேரத்தை குறித்துக்கொண்டு உடனே 108 அழைக்கவும்.",
      operator_briefing: `Acute stroke suspected at ${location}. FAST positive. Symptoms began recently. Urgent stroke unit needed.`
    };
  }

  // 5. Seizure / Fits
  if (anyWord(n, ['seiz', 'fit', 'convuls', 'epilep', 'jerking', 'வலிப்பு', 'காக்காய் வலிப்பு', 'துடித்தல்'])) {
    return {
      is_authentic: true,
      authenticity_score: 98,
      authenticity_rationale: "Generalized tonic-clonic epileptic convulsion (Protocol 7).",
      matched_protocol: "Protocol 7: Medical Emergencies - Seizures & Fits",
      should_give_first_aid: true,
      decision_headline: "CUSHION HEAD • PROTECT AIRWAY • STRICTLY NOTHING IN MOUTH",
      critical_do_nots: [
        "DO NOT put iron keys, spoons, cloth, or fingers into the person's mouth (fractures teeth and chokes airway).",
        "DO NOT physically restrain the person or try to hold their thrashing limbs down.",
        "DO NOT give water or fluids until they are fully conscious and alert."
      ],
      safe_action_steps: [
        "Clear dangerous sharp, hard, or hot objects away from the casualty.",
        "Place a soft jacket, folded towel, or pillow gently under their head to prevent skull trauma.",
        "Time the convulsion; call 108 immediately if seizure lasts longer than 5 minutes or repeats.",
        "Once jerking stops, gently turn the person onto their side into recovery position to drain saliva."
      ],
      tamil_audio_guide: "வலிப்பு வரும்போது வாயில் இரும்பு சாவி, கரண்டி அல்லது விரலை திணிக்கவே கூடாது! அவர்களை பிடித்து அமுக்காதீர்கள். தலைக்கு அடியில் மென்மையான துணியை வையுங்கள். வலிப்பு முடிந்ததும் ஒருக்களித்து படுக்க வையுங்கள்.",
      operator_briefing: `Active convulsive seizure at ${location}. Patient protected from trauma. Airway monitored.`
    };
  }

  // 6. Snakebite
  if (anyWord(n, ['snake', 'bite', 'venom', 'viper', 'cobra', 'krait', 'பாம்பு', 'கடி', 'விஷம்'])) {
    return {
      is_authentic: true,
      authenticity_score: 99,
      authenticity_rationale: "Suspected venomous ophidian envenomation (Protocol 8).",
      matched_protocol: "Protocol 8: Poisoning, Snakebite, Animal Bites & Anaphylaxis",
      should_give_first_aid: true,
      decision_headline: "IMMOBILIZE LIMB BELOW HEART • STRICTLY NO CUTTING OR SUCKING",
      critical_do_nots: [
        "DO NOT cut the bite site with blades or knives (causes uncontrollable hemorrhage).",
        "DO NOT attempt to suck venom by mouth or mechanical pump.",
        "DO NOT apply tight arterial tourniquets, ropes, or rubber bands (causes gangrene and limb loss).",
        "DO NOT apply ice packs, herbal pastes, electrical shocks, or hot ash to wound."
      ],
      safe_action_steps: [
        "Keep the victim calm, calm and COMPLETELY IMMOBILE; walking pumps venom into lymphatic circulation.",
        "Immobilize the bitten limb using a rigid stick/splint; keep limb BELOW the level of the heart.",
        "Gently remove tight rings, watches, bracelets, or anklets before swelling sets in.",
        "Transport immediately to nearest hospital equipped with Anti-Snake Venom (ASV). Call 108."
      ],
      tamil_audio_guide: "பாம்பு கடித்த இடத்தில் பிளேடால் வெட்டவோ, வாயால் விஷத்தை உறிஞ்சவோ, இறுக்கமாக கயிறு கட்டவோ கூடாது! நபரை நடக்க விடாமல் படுக்க வைத்து, கடித்த பகுதியை இதயத்திற்கு கீழ் வைத்து உடனே 108 ஆம்புலன்ஸில் மருத்துவமனைக்கு அழைத்துச் செல்லவும்.",
      operator_briefing: `Venomous snakebite at ${location}. Bitten limb splinted and immobilized below heart. No tourniquet used. Urgent Anti-Snake Venom (ASV) needed.`
    };
  }

  // 7. Animal Bite / Dog Bite
  if (anyWord(n, ['dog', 'rabies', 'animal bite', 'cat bite', 'stray', 'நாய்', 'விலங்கு கடி', 'வெறிநாய்'])) {
    return {
      is_authentic: true,
      authenticity_score: 98,
      authenticity_rationale: "Animal bite wound with high rabies transmission risk (Protocol 8).",
      matched_protocol: "Protocol 8: Animal Bites & Rabies Prevention",
      should_give_first_aid: true,
      decision_headline: "WASH WITH SOAP & RUNNING WATER FOR 15 MINUTES • GET RABIES VACCINE",
      critical_do_nots: [
        "DO NOT apply chili powder, turmeric, coffee powder, lime, oils, or cow dung into bite wound.",
        "DO NOT suture, stitch, or tightly bandage fresh animal bite wounds immediately.",
        "DO NOT ignore minor scratches, abrasions, or animal saliva on broken skin."
      ],
      safe_action_steps: [
        "Immediately wash the bite/scratch vigorously with household soap and running water for AT LEAST 15 MINUTES.",
        "Apply povidone-iodine or medical antiseptic solution freely over wound after flushing.",
        "Cover loosely with a clean, sterile cloth gauze.",
        "Take victim to hospital within 24 hours for Post-Exposure Prophylaxis (Rabies Vaccine + Rabies Immunoglobulin)."
      ],
      tamil_audio_guide: "நாய் அல்லது விலங்கு கடித்தால், கடித்த இடத்தை பைப் தண்ணீரில் சோப்பு போட்டு குறைந்தது 15 நிமிடங்கள் விடாமல் நன்றாக கழுவவும். காப்பித்தூள், மஞ்சள் வைக்கக்கூடாது. 24 மணி நேரத்திற்குள் ரேபிஸ் தடுப்பூசி போடவும்.",
      operator_briefing: `Animal bite exposure at ${location}. 15-minute soap/water wash completed. Needs anti-rabies post-exposure prophylaxis.`
    };
  }

  // 8. Thermal Burns
  if (anyWord(n, ['burn', 'scald', 'fire', 'hot water', 'blister', 'தீக்காயம்', 'சுடுதண்ணீர்', 'தீ'])) {
    return {
      is_authentic: true,
      authenticity_score: 98,
      authenticity_rationale: "Thermal dermal scald / flame burn injury (Protocol 5).",
      matched_protocol: "Protocol 5: Burns, Scalds & Chemical Injuries",
      should_give_first_aid: true,
      decision_headline: "COOL WITH RUNNING WATER FOR 20 FULL MINUTES • NO ICE • NO OINTMENTS",
      critical_do_nots: [
        "DO NOT apply ice, ice water, or frozen packs (worsens tissue death through constriction).",
        "DO NOT apply toothpaste, butter, oils, raw egg, turmeric, or ink.",
        "DO NOT burst blisters (blisters are natural sterile bandages preventing infection).",
        "DO NOT peel off clothing melted or adhered to burnt flesh."
      ],
      safe_action_steps: [
        "Immediately hold burnt area under cool, clean running tap water for at least 20 MINUTES.",
        "Gently remove non-adherent clothing and constricting rings or watches before tissue swells.",
        "Cover loosely with clean transparent cling film or a sterile non-stick plastic sheet.",
        "Keep patient warm with a blanket over unburned areas; call 108 if burns are on face, hands, or large surface."
      ],
      tamil_audio_guide: "தீக்காயம் பட்ட இடத்தில் உடனடியாக ஓடும் குளிர்ந்த நீரில் குறைந்தது 20 நிமிடங்கள் தொடர்ந்து அலசவும். ஐஸ், பற்பசை (toothpaste), நெய் அல்லது மஞ்சள் வைக்கவே கூடாது! கொப்புளங்களை உடைக்காதீர்கள்.",
      operator_briefing: `Severe thermal burn injury at ${location}. 20-minute cool running water irrigation underway. Blisters intact.`
    };
  }

  // 9. Chemical Splash (Eyes & Skin)
  if (anyWord(n, ['chemical', 'acid', 'battery', 'splash', 'கெமிக்கல்', 'அமிலம்', 'ஆசிட்'])) {
    return {
      is_authentic: true,
      authenticity_score: 99,
      authenticity_rationale: "Acute chemical tissue corrosion exposure (Protocol 5).",
      matched_protocol: "Protocol 5: Chemical Burns & Splash Injuries",
      should_give_first_aid: true,
      decision_headline: "CONTINUOUS COPIOUS WATER FLUSH FOR 20+ MINUTES • DILUTION ONLY",
      critical_do_nots: [
        "DO NOT attempt to chemically neutralize acids with bases/alkalis (produces severe exothermic heat).",
        "DO NOT rub eyes or scratch affected skin.",
        "DO NOT put oily drops or medicated creams into eyes."
      ],
      safe_action_steps: [
        "Immediately flush eyes or affected skin with gentle, continuous clean running water for at least 20 minutes.",
        "For eye exposure: hold eyelids wide open with fingers and ensure water flows across from inner to outer corner.",
        "Carefully strip off all chemical-contaminated clothing while continuing irrigation.",
        "Transport immediately to emergency ophthalmic/burn trauma center (Call 108)."
      ],
      tamil_audio_guide: "கண்களிலோ தோலிலோ அமிலம் அல்லது கெமிக்கல் பட்டால் உடனடியாக ஓடும் நீரில் குறைந்தது 20 நிமிடங்கள் தொடர்ந்து கழுவவும். கண்களை கசக்கக் கூடாது. அமிலத்தை சமன் செய்ய வேறு எதையும் ஊற்ற வேண்டாம்.",
      operator_briefing: `Chemical exposure burn at ${location}. Continuous water irrigation in progress. Specialist ophthalmic care needed.`
    };
  }

  // 10. Severe Bleeding & Wounds
  if (anyWord(n, ['bleed', 'blood', 'gash', 'cut', 'artery', 'ரத்தம்', 'இரத்தப்போக்கு', 'வெட்டுக்காயம்'])) {
    return {
      is_authentic: true,
      authenticity_score: 98,
      authenticity_rationale: "Uncontrolled external hemorrhage (Protocol 4).",
      matched_protocol: "Protocol 4: Severe Bleeding, Wounds & Nosebleeds",
      should_give_first_aid: true,
      decision_headline: "CONTINUOUS DIRECT PRESSURE • ELEVATE • DO NOT REMOVE FIRST CLOTH",
      critical_do_nots: [
        "DO NOT lift the first cloth or gauze to peek at the wound (dislodges forming blood clots).",
        "DO NOT remove deeply embedded knife blades or impaled objects (they act as a plug stopping blood loss).",
        "DO NOT wash out severe, deep, actively spurting wounds with water."
      ],
      safe_action_steps: [
        "Press a clean cloth, sterile pad, or bare gloved hands firmly and directly over the wound with continuous force.",
        "If blood soaks through, place another pad directly on top; maintain hard continuous pressure.",
        "Elevate the bleeding limb above the level of the heart if no bone fracture is suspected.",
        "For catastrophic arterial limb bleeding not stopped by direct pressure: apply commercial tourniquet 5-7cm above wound and record time."
      ],
      tamil_audio_guide: "சுத்தமான துணியை வைத்து ரத்தம் வழியும் இடத்தில் கை எடுக்காமல் தொடர்ந்து பலமாக அழுத்தவும். ரத்தம் நனைந்தாலும் துணியை எடுக்காமல் அதற்கு மேல் மற்றொரு துணியை வைக்கவும். காயம் ஏற்பட்ட பகுதியை இதயத்திற்கு மேல் உயர்த்தவும்.",
      operator_briefing: `Severe uncontrolled hemorrhage at ${location}. Direct pressure applied. Blood transfusion alert required.`
    };
  }

  // 11. Nosebleeds
  if (anyWord(n, ['nose', 'nosebleed', 'epistaxis', 'மூக்கு', 'மூக்கில் ரத்தம்'])) {
    return {
      is_authentic: true,
      authenticity_score: 95,
      authenticity_rationale: "Anterior epistaxis nasal hemorrhage (Protocol 4).",
      matched_protocol: "Protocol 4: Nosebleeds (Epistaxis)",
      should_give_first_aid: true,
      decision_headline: "LEAN HEAD FORWARD • PINCH SOFT NOSE FIRMLY FOR 10-15 MINUTES",
      critical_do_nots: [
        "DO NOT tilt the head backward (blood runs down throat into stomach, causing vomiting and airway choking).",
        "DO NOT pack the nostrils with unsterile paper towels, tissues, or cotton balls.",
        "DO NOT blow nose or sniff vigorously for several hours after bleeding stops."
      ],
      safe_action_steps: [
        "Sit upright and lean head slightly FORWARD over a basin or towel.",
        "Pinch the soft lower part of both nostrils firmly closed between thumb and index finger.",
        "Breathe through the mouth and maintain continuous pinch pressure for 10-15 minutes without releasing.",
        "Place an ice pack wrapped in cloth across forehead or bridge of nose."
      ],
      tamil_audio_guide: "தலையை பின்னால் சாய்க்கக் கூடாது! தலையை சற்று முன்னால் குனிந்து, மூக்கின் மென்மையான பகுதியை 10 முதல் 15 நிமிடங்கள் விடாமல் அழுத்திப் பிடிக்கவும். வாய் வழியாக மூச்சு விடவும்.",
      operator_briefing: `Epistaxis (nosebleed) at ${location}. Forward lean and nasal compression active.`
    };
  }

  // 12. Fractures & Broken Bones
  if (anyWord(n, ['fracture', 'broken', 'bone', 'deformity', 'sprain', 'எலும்பு', 'முறிவு', 'ஒடிந்து'])) {
    return {
      is_authentic: true,
      authenticity_score: 97,
      authenticity_rationale: "Closed/Open skeletal fracture or joint dislocation (Protocol 6).",
      matched_protocol: "Protocol 6: Fractures, Sprains & Strains",
      should_give_first_aid: true,
      decision_headline: "IMMOBILIZE & SUPPORT IN POSITION FOUND • DO NOT REALIGN BONES",
      critical_do_nots: [
        "DO NOT attempt to push back protruding bone ends or force deformed bones straight.",
        "DO NOT massage, rub, or manipulate a suspected broken limb.",
        "DO NOT allow casualty to walk on an injured leg or foot."
      ],
      safe_action_steps: [
        "Support the fractured bone and joints above and below in the exact position found.",
        "Use rolled blankets, jackets, or rigid splints wrapped with cloth to immobilize the limb.",
        "Cover open fracture wounds with clean sterile dressings without pressing on exposed bone.",
        "Apply ice pack wrapped in a cloth towel to reduce swelling; check fingers/toes are warm and pink."
      ],
      tamil_audio_guide: "உடைந்த எலும்பையோ அல்லது மூட்டையோ நேராக்க முயற்சிக்காதீர்கள்! அது இருக்கும் நிலையிலேயே அசையாமல் துணி அல்லது கட்டை வைத்து தாங்கிப் பிடிக்கவும். காயத்தில் மசாஜ் செய்யக் கூடாது. 108 அழைக்கவும்.",
      operator_briefing: `Suspected skeletal fracture at ${location}. Limb immobilized in position found. Circulation intact.`
    };
  }

  // 13. Electric Shock
  if (anyWord(n, ['electric', 'shock', 'wire', 'electrocution', 'கரண்ட்', 'மின்சாரம்', 'மின்கம்பி'])) {
    return {
      is_authentic: true,
      authenticity_score: 99,
      authenticity_rationale: "High/Low-voltage electrical contact trauma (Protocol 9).",
      matched_protocol: "Protocol 9: Electric Shock & Electrocution",
      should_give_first_aid: true,
      decision_headline: "DISCONNECT POWER BEFORE TOUCHING CASUALTY • DRY NON-CONDUCTOR • CPR",
      critical_do_nots: [
        "DO NOT touch the casualty with bare hands or conductive metal while they are in contact with electricity.",
        "DO NOT use damp, wet, or metal objects to push wires away.",
        "DO NOT approach high-voltage overhead cables (maintain minimum 10-meter clearance)."
      ],
      safe_action_steps: [
        "Switch off main electrical breaker power supply immediately.",
        "If power cannot be cut, stand on dry rubber/wood and use a dry wooden stick to push wire away.",
        "Once separated from current and scene is safe, check breathing immediately.",
        "If casualty is unresponsive and not breathing, begin CPR chest compressions immediately; call 108."
      ],
      tamil_audio_guide: "கரண்ட் பாயும் நபரை வெறும் கையால் தொடக்கூடாது! முதலில் மெயின் சுவிட்சை ஆஃப் செய்யவும். முடியாத பட்சத்தில் காய்ந்த மரக்கட்டை மூலம் அவரை பிரிக்கவும். மூச்சு இல்லாவிட்டால் உடனே சிபிஆர் (CPR) செய்யவும்.",
      operator_briefing: `Electrocution incident at ${location}. Power isolated. Airway/breathing triage in progress.`
    };
  }

  // 14. Asthma Attack
  if (anyWord(n, ['asthma', 'wheez', 'inhaler', 'inability to breathe', 'ஆஸ்துமா', 'இளைப்பு', 'மூச்சு'])) {
    return {
      is_authentic: true,
      authenticity_score: 97,
      authenticity_rationale: "Acute bronchospasm / Severe asthma exacerbation (Protocol 10).",
      matched_protocol: "Protocol 10: Asthma & Respiratory Distress",
      should_give_first_aid: true,
      decision_headline: "SIT UPRIGHT • 4 PUFFS INHALER VIA SPACER • SLOW BREATHS • CALL 108",
      critical_do_nots: [
        "DO NOT make the person lie flat (lying down collapses small airways and severely impairs diaphragm).",
        "DO NOT crowd around the casualty (ensure abundant fresh airflow).",
        "DO NOT give sedative tablets or warm water."
      ],
      safe_action_steps: [
        "Seat person comfortably upright, leaning slightly forward with arms resting on knees or table.",
        "Assist them in using their blue reliever inhaler (Salbutamol): 1 puff every 30-60 seconds, up to 4 puffs.",
        "Wait 4 minutes; if breathing is still strained, give another 4 puffs.",
        "If no improvement after 8 puffs or lips turn blue/pale, call 108 immediately."
      ],
      tamil_audio_guide: "ஆஸ்துமா மூச்சுத்திணறல் ஏற்பட்டவரை படுக்க வைக்காதீர்கள்! நிமிர்ந்து உட்கார வையுங்கள். இன்ஹேலர் (Inhaler) இருந்தால் 4 முறை உள்ளிழுக்க உதவி செய்யுங்கள். கூட்டம் கூடாமல் காற்று வர அனுமதியுங்கள்.",
      operator_briefing: `Severe acute asthma attack at ${location}. Reliever inhaler administered. Respiratory distress ongoing.`
    };
  }

  // 15. Diabetes / Low Blood Sugar
  if (anyWord(n, ['diabet', 'sugar', 'hypoglycemia', 'insulin', 'சர்க்கரை', 'மயக்கம்', 'குறைந்த சர்க்கரை'])) {
    return {
      is_authentic: true,
      authenticity_score: 96,
      authenticity_rationale: "Acute neuroglycopenic hypoglycemia (Protocol 10).",
      matched_protocol: "Protocol 10: Low Blood Sugar (Hypoglycemia)",
      should_give_first_aid: true,
      decision_headline: "FAST SUGAR IF CONSCIOUS • STRICTLY NOTHING BY MOUTH IF DROWSY",
      critical_do_nots: [
        "DO NOT give food, drinks, or glucose to anyone who is drowsy or unconscious (leads to fatal choking).",
        "DO NOT administer insulin injections to an unconscious diabetic person."
      ],
      safe_action_steps: [
        "If person is conscious and able to swallow: give 15-20g fast-acting sugar (fruit juice, glucose candy, sugary drink).",
        "Wait 10-15 minutes and reassess; give carbohydrate snack (bread, biscuits) once alert.",
        "If casualty is drowsy, confused, or loses consciousness: place in lateral recovery position, call 108 immediately."
      ],
      tamil_audio_guide: "சுயநினைவுடன் விழுங்க முடிந்தால் மட்டுமே பழச்சாறு அல்லது சர்க்கரை தண்ணீர் கொடுக்கவும். மயக்கமாகவோ அல்லது விழுங்க முடியாமலோ இருந்தால் வாயில் எதையும் ஊற்றக் கூடாது! உடனே 108-ஐ அழைக்கவும்.",
      operator_briefing: `Diabetic hypoglycemic crisis at ${location}. Conscious state evaluated. Paramedic glucose needed.`
    };
  }

  // 16. Poisoning / Overdose
  if (anyWord(n, ['poison', 'overdose', 'swallow chemical', 'pesticide', 'விஷம்', 'மருந்து'])) {
    return {
      is_authentic: true,
      authenticity_score: 98,
      authenticity_rationale: "Acute chemical or pharmaceutical toxic ingestion (Protocol 8).",
      matched_protocol: "Protocol 8: Poisoning & Overdose",
      should_give_first_aid: true,
      decision_headline: "STRICTLY DO NOT INDUCE VOMITING • DO NOT GIVE MILK • CALL 108",
      critical_do_nots: [
        "DO NOT induce vomiting (corrosive poisons burn esophagus and vocal cords twice on way back up).",
        "DO NOT give milk, raw eggs, or salt water (can accelerate chemical absorption).",
        "DO NOT wait for symptoms to appear before calling emergency services."
      ],
      safe_action_steps: [
        "Call 108 / 112 immediately and report the specific chemical or medicine name.",
        "Keep the exact chemical container, bottle, or pill strip to give directly to doctors.",
        "If poison was on skin or in eyes, wash continuously with water.",
        "If person becomes unconscious, roll into recovery position and monitor airway."
      ],
      tamil_audio_guide: "விஷம் குடித்தவருக்கு வாந்தி எடுக்க வைக்கக் கூடாது! பால் அல்லது உப்பு தண்ணீர் கொடுக்க வேண்டாம். விஷ பாட்டிலை எடுத்துக்கொண்டு உடனடியாக 108 ஆம்புலன்ஸில் செல்லவும்.",
      operator_briefing: `Acute toxic poisoning at ${location}. Chemical container secured. No vomiting induced. Urgent toxicological triage.`
    };
  }

  // 17. Road Traffic Accidents & Cervical Spine (Helmet)
  if (anyWord(n, ['crash', 'bike', 'car', 'accident', 'helmet', 'motorcycle', 'விபத்து', 'ஹெல்மெட்', 'பைக்', 'வாகனம்', 'மோதி'])) {
    return {
      is_authentic: true,
      authenticity_score: 98,
      authenticity_rationale: "High-velocity vehicular impact with potential cervical spine trauma (Protocol 6).",
      matched_protocol: "Protocol 6: Road Traffic Accidents, Head, Neck & Spine Trauma",
      should_give_first_aid: true,
      decision_headline: "DO NOT REMOVE HELMET • SUPPORT CERVICAL SPINE • CONTROL EXTERNAL BLEEDING",
      critical_do_nots: [
        "DO NOT remove a motorcycle helmet unless essential to maintain airway or perform CPR and you are trained.",
        "DO NOT move, twist, or tilt the person's neck, head, or spine.",
        "DO NOT offer water, food, or medication to road crash victims."
      ],
      safe_action_steps: [
        "Park vehicle safely, put hazard flashers on, turn off vehicle ignitions, and call 108 on speaker.",
        "Support casualty's head and neck with both hands in the exact neutral position found without movement.",
        "Apply firm direct pressure with clean cloth over any external bleeding wounds.",
        "Keep casualty warm and monitor breathing continuously until trauma team arrives."
      ],
      tamil_audio_guide: "கழுத்தையோ தலையையோ அசைக்காதீர்கள். ஹெல்மெட் இருந்தால் கழற்றாதீர்கள். தண்ணீர் கொடுக்காதீர்கள். ரத்தப்போக்கு உள்ள இடத்தில் மட்டும் சுத்தமான துணியை வைத்து அழுத்தவும்.",
      operator_briefing: `Road collision at ${location}. Cervical spine stabilization maintained. Helmet left in place. Level-1 trauma response required.`
    };
  }

  // 18. General Emergency Default (Protocol 1)
  return {
    is_authentic: true,
    authenticity_score: 95,
    authenticity_rationale: "General emergency clinical evaluation under 2026 First Aid Guidelines.",
    matched_protocol: "Protocol 1: The First Minute - Scene Safety & Initial Assessment",
    should_give_first_aid: true,
    decision_headline: "VERIFY SCENE SAFETY • CALL 108/112 • CHECK BREATHING & CONSCIOUSNESS",
    critical_do_nots: [
      "DO NOT put yourself in danger before approaching the casualty.",
      "DO NOT move the casualty unless there is immediate mortal danger (fire, flood, traffic).",
      "DO NOT give water or fluids to an unconscious person."
    ],
    safe_action_steps: [
      "Check scene for hazards (traffic, electricity, toxic gas, fire).",
      "Call 108 (Ambulance) or 112 (Unified SOS) immediately on speakerphone.",
      "Check responsiveness: gently tap shoulders and ask loudly 'Can you hear me?'.",
      "Look, listen, and feel for normal breathing for 10 seconds; if absent, begin CPR immediately."
    ],
    tamil_audio_guide: "முதலில் விபத்து நடந்த இடம் உங்களுக்கு பாதுகாப்பாக உள்ளதா என்று பாருங்கள். உடனடியாக 108 அல்லது 112 அவசர எண்ணுக்கு அழைக்கவும். பாதிக்கப்பட்டவர் மூச்சு விடுகிறாரா என்பதை சோதிக்கவும். நினைவு இல்லாவிட்டால் உடனே சிபிஆர் (CPR) தொடங்கவும்.",
    operator_briefing: `Emergency at ${location}. Scene safety verified. Bystander first responder on scene. Ambulance requested.`
  };
}

function anyWord(str, words) {
  return words.some(w => str.includes(w));
}

// ==========================================
// 12. 24x7 EMERGENCY HELPLINES MODAL & SPEED DIAL
// ==========================================
function openEmergencyModal() {
  const modal = document.getElementById('emergency-modal');
  if (modal) {
    modal.classList.toggle('hidden');
    if (!modal.classList.contains('hidden')) {
      playChime(660);
    }
  }
}

function copyGpsForEmergencyCall() {
  const locInput = document.getElementById('incident-location');
  const text = locInput ? locInput.value : `${currentCoords.lat.toFixed(6)}, ${currentCoords.lng.toFixed(6)}`;
  
  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).then(() => {
      alert(`📍 GPS Coordinates copied to clipboard!

${text}

You can read or SMS this directly to the 108/112 ambulance operator.`);
    }).catch(() => {
      prompt('Copy your GPS coordinates to provide to 108/112 operator:', text);
    });
  } else {
    prompt('Copy your GPS coordinates to provide to 108/112 operator:', text);
  }
}

function copyOperatorBriefing() {
  const briefing = document.getElementById('gemini-operator-briefing');
  const text = briefing ? briefing.innerText : '';
  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).then(() => {
      alert("📋 112/108 Operator Briefing copied to clipboard!\nYou can read or paste this directly during your emergency call.");
    });
  } else {
    prompt("Copy Operator Briefing:", text);
  }
}

// ========================================================
// 13. OFFICIAL 2026 FIRST AID HANDBOOK BROWSER MODAL
// ========================================================
let firstAidHandbookData = null;

async function openFirstAidHandbookModal() {
  const modal = document.getElementById('firstaid-handbook-modal');
  if (!modal) return;
  modal.classList.toggle('hidden');

  if (!modal.classList.contains('hidden') && !firstAidHandbookData) {
    try {
      const res = await fetch(`${API_BASE}/api/first-aid/protocols`);
      firstAidHandbookData = await res.json();
      renderFirstAidHandbook(firstAidHandbookData);
    } catch (e) {
      console.warn("Failed to fetch first aid protocols:", e);
    }
  }
}

function renderFirstAidHandbook(data) {
  const container = document.getElementById('handbook-protocols-container');
  if (!container || !data || !data.protocols) return;

  container.innerHTML = data.protocols.map(p => `
    <div class="glass-panel-pro p-4 rounded-xl border border-purple-500/30 space-y-2.5">
      <div class="flex items-center justify-between pb-2 border-b border-purple-500/20">
        <div class="flex items-center space-x-2.5">
          <span class="w-6 h-6 rounded-full bg-purple-900 border border-purple-500/50 flex items-center justify-center text-xs font-mono font-bold text-amber-400">${p.id}</span>
          <h4 class="text-xs sm:text-sm font-bold text-white font-sans">${p.title}</h4>
        </div>
        <span class="text-xs font-tamil text-purple-300 font-bold">${p.tamil_title}</span>
      </div>
      <div>
        <span class="text-[10px] font-sans uppercase text-emerald-400 font-bold block mb-1 tracking-wider">Safe Action Steps:</span>
        <ul class="text-xs font-sans text-purple-100 list-disc pl-4 space-y-1 font-normal leading-relaxed">
          ${p.actions.map(a => `<li>${a}</li>`).join('')}
        </ul>
      </div>
      ${p.critical_do_nots && p.critical_do_nots.length ? `
        <div class="p-2.5 rounded-lg bg-red-950/40 border border-red-500/30">
          <span class="text-[10px] font-sans uppercase text-red-300 font-bold block mb-1 tracking-wider">Critical Warnings (DO NOT):</span>
          <ul class="text-xs font-sans text-red-200 list-disc pl-4 space-y-1 font-normal leading-relaxed">
            ${p.critical_do_nots.map(d => `<li>${d}</li>`).join('')}
          </ul>
        </div>
      ` : ''}
    </div>
  `).join('');
}

  
// =========================================================================
// HORIZONTAL TOUCH-SWIPE MAP CAROUSEL LOGIC (Slide 0: Route | Slide 1: Radar | Slide 2: Green Wave)
// =========================================================================
let currentMapSlideIndex = 0;

function scrollMapSlide(index) {
  const carousel = document.getElementById('map-swipe-carousel');
  if (!carousel) return;
  const slideWidth = carousel.clientWidth;
  carousel.scrollTo({
    left: index * slideWidth,
    behavior: 'smooth'
  });
  updateMapCarouselIndicators(index);
}

function nextMapSlide() {
  currentMapSlideIndex = (currentMapSlideIndex + 1) % 3;
  scrollMapSlide(currentMapSlideIndex);
}

function prevMapSlide() {
  currentMapSlideIndex = (currentMapSlideIndex - 1 + 3) % 3;
  scrollMapSlide(currentMapSlideIndex);
}

function handleMapCarouselScroll() {
  const carousel = document.getElementById('map-swipe-carousel');
  if (!carousel) return;
  const slideWidth = carousel.clientWidth;
  const activeIndex = Math.round(carousel.scrollLeft / slideWidth);
  if (activeIndex !== currentMapSlideIndex && activeIndex >= 0 && activeIndex < 3) {
    currentMapSlideIndex = activeIndex;
    updateMapCarouselIndicators(activeIndex);
  }
}

function updateMapCarouselIndicators(index) {
  // Update Tabs
  for (let i = 0; i < 3; i++) {
    const tab = document.getElementById(`tab-slide-${i}`);
    const dot = document.getElementById(`dot-map-${i}`);
    if (tab) {
      if (i === index) {
        tab.className = "px-2.5 py-1 rounded-lg bg-cyan-600 text-white font-bold text-[10px] shadow-[0_0_12px_rgba(6,182,212,0.6)] transition-all flex items-center gap-1 cursor-pointer";
      } else {
        tab.className = "px-2.5 py-1 rounded-lg bg-purple-950/80 border border-purple-500/30 text-purple-300 text-[10px] hover:text-white transition-all flex items-center gap-1 cursor-pointer";
      }
    }
    if (dot) {
      if (i === index) {
        dot.className = "w-3 h-1.5 rounded-full bg-cyan-400 transition-all pointer-events-auto cursor-pointer shadow-[0_0_8px_#06b6d4]";
      } else {
        dot.className = "w-1.5 h-1.5 rounded-full bg-purple-500/50 hover:bg-cyan-400 transition-all pointer-events-auto cursor-pointer";
      }
    }
  }
}
